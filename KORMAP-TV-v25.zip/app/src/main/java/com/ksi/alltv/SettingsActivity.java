/*
 * MIT License
 *
 * Copyright (c) 2019 PYTHONKOR

 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:

 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.

 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

package com.ksi.alltv;

import android.app.Activity;
import android.app.Instrumentation;
import android.content.Context;
import android.content.Intent;
import android.graphics.Point;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.leanback.app.GuidedStepSupportFragment;
import androidx.leanback.widget.GuidedAction;
import androidx.leanback.widget.GuidanceStylist.Guidance;
import androidx.leanback.widget.GuidedDatePickerAction;
import androidx.fragment.app.FragmentManager;
import android.text.InputType;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;

import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.Locale;
import java.util.List;
import java.util.Date;
import java.text.SimpleDateFormat;


public class SettingsActivity extends FragmentActivity {

    private static final String TAG = SettingsActivity.class.getSimpleName();
    private static SettingsData mSettings;
    private Point mWindowSize;

    public enum GuidedId {
        GuidedIdStart,
        Pooq, PooqEnable, PooqId, PooqPw, PooqQuality, PooqMobile, PooqSD, PooqHD, PooqFHD, PooqSave, PooqLogout,
        Tving, TvingEnable, TvingWebLogin, TvingCjOneId, TvingId, TvingPw, TvingQuality, TvingAuto, TvingMD, TvingSD, TvingHD, TvingFHD, TvingSave, TvingLogout,
        Oksusu, OksusuEnable, OksusuId, OksusuPw, OksusuQuality, OksusuAuto, OksusuFullHd, OksusuHd, OksusuSd, OksusuSave
    }

    private String getStringById(int resourceId) {
        return this.getResources().getString(resourceId);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (null == savedInstanceState) {
            Gson gson = new Gson();
            mSettings = gson.fromJson(getIntent().getStringExtra(getStringById(R.string.SETTINGSDATA_STR)), SettingsData.class);
            GuidedStepSupportFragment.addAsRoot(this, new MainStepFragment(), android.R.id.content);
        }
        mWindowSize = Utils.getDisplaySize(this);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {

        if(event.getAction() == MotionEvent.ACTION_UP) {

            float left, right, top, bottom, mid;

            left  = (float) (mWindowSize.x * 0.1);
            right = (float) (mWindowSize.x * 0.9);
            mid   = (float) (mWindowSize.y * 0.5);
            top = left;
            bottom = (float)(mWindowSize.y - top);

            if(event.getX() < left) {
                if (event.getY() < top) {
                    new Thread(new Runnable() {
                        public void run() {
                            new Instrumentation().sendKeyDownUpSync(KeyEvent.KEYCODE_DPAD_UP);
                        }
                    }).start();
                } else if (event.getY() > bottom) {
                    new Thread(new Runnable() {
                        public void run() {
                            new Instrumentation().sendKeyDownUpSync(KeyEvent.KEYCODE_DPAD_DOWN);
                        }
                    }).start();
                } else if (event.getY() > (mid-50) && event.getY() < (mid+50)) {
                    new Thread(new Runnable() {
                        public void run() {
                            new Instrumentation().sendKeyDownUpSync(KeyEvent.KEYCODE_DPAD_CENTER);
                        }
                    }).start();
                }
            }

        }

        return super.onTouchEvent(event);
    }

    private static void addAction(Context context, List<GuidedAction> actions, long id, String title, String desc) {
        addAction(context, actions, id, title, desc, null);
    }

    private static void addAction(Context context, List<GuidedAction> actions, long id, String title, String desc, Drawable icon) {
        GuidedAction.Builder builder = new GuidedAction.Builder(context)
                .id(id)
                .title(title)
                .description(desc);

        if (icon != null) {
            builder.icon(icon);
        }

        actions.add(builder.build());
    }

    private static void addEditableAction(Context context, List<GuidedAction> actions, long id, String title, String desc, int inputType) {
        actions.add(new GuidedAction.Builder(context)
                .id(id)
                .title(title)
                .descriptionEditable(true)
                .descriptionInputType(inputType)
                .description(desc)
                .build());
    }

    private static void addEditablePasswordAction(Context context, List<GuidedAction> actions, long id, String title, String desc, String password) {
        actions.add(new GuidedAction.Builder(context)
                .id(id)
                .title(title)
                .description(desc)
                .editDescription(password)
                .descriptionEditInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD)
                .descriptionEditable(true)
                .build());
    }

    private static void addDropDownAction(Context context, List<GuidedAction> actions, long id, String title, String desc, List<GuidedAction> selectionActions) {
        actions.add(new GuidedAction.Builder(context)
                .id(id)
                .title(title)
                .description(desc)
                .subActions(selectionActions)
                .build());
    }

    private static void addCheckedAction(Context context, List<GuidedAction> actions, long id, String title, String desc, boolean checked) {
        GuidedAction guidedAction = new GuidedAction.Builder(context)
                .id(id)
                .title(title)
                .description(desc)
                .checkSetId(GuidedAction.CHECKBOX_CHECK_SET_ID)
                .build();
        guidedAction.setChecked(checked);
        actions.add(guidedAction);
    }

    private static void addDateAction(Context context, List<GuidedAction> actions, long id, String title, long date) {
        actions.add(new GuidedDatePickerAction.Builder(context)
                .id(id)
                .date(date)
                .datePickerFormat("YMD")
                .maxDate(new Date().getTime())
                .title(title)
                .build());
    }

    private static String getEditableActionText(GuidedAction action) {
        if (action == null) {
            return "";
        }

        CharSequence editDescription = action.getEditDescription();
        if (editDescription != null && editDescription.length() > 0) {
            return editDescription.toString();
        }

        CharSequence description = action.getDescription();
        if (description != null && description.length() > 0) {
            return description.toString();
        }

        return "";
    }

    private static boolean hasText(String value) {
        return value != null && value.trim().length() > 0;
    }

    private static void clearBaseSettings(Context context, SettingsData.BaseSettingsData settings) {
        if (settings == null) {
            return;
        }

        settings.mEnable = false;
        settings.mId = "";
        settings.mPassword = "";
        settings.mLastSavedAt = System.currentTimeMillis();
        settings.mLastCheckedAt = 0L;
        settings.mLastStatus = context.getString(R.string.login_status_not_set);
    }

    private static void clearTvingSettings(Context context, SettingsData.TvingSettingsData settings) {
        clearBaseSettings(context, settings);
        if (settings == null) {
            return;
        }

        settings.mSessionCookie = "";
        settings.mCJOneId = false;
        if (settings.mQualityType == null) {
            settings.mQualityType = SettingsData.TvingQualityType.AUTO;
        }
    }

    private static String formatStatusTime(long timeMillis) {
        if (timeMillis <= 0L) {
            return "-";
        }

        return new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.KOREA).format(new Date(timeMillis));
    }

    private static String getStatusText(Context context, SettingsData.BaseSettingsData settings) {
        if (settings == null) {
            return context.getString(R.string.login_status_not_set);
        }

        if (settings instanceof SettingsData.TvingSettingsData) {
            SettingsData.TvingSettingsData tvingSettings = (SettingsData.TvingSettingsData) settings;
            if (tvingSettings.mSessionCookie != null &&
                    tvingSettings.mSessionCookie.trim().length() > 0 &&
                    (tvingSettings.mLastStatus == null || tvingSettings.mLastStatus.trim().length() == 0)) {
                return context.getString(R.string.login_status_ok);
            }
        }

        if (settings.mLastStatus != null && settings.mLastStatus.trim().length() > 0) {
            return settings.mLastStatus;
        }

        if (settings.mId != null && settings.mId.trim().length() > 0 &&
                settings.mPassword != null && settings.mPassword.trim().length() > 0) {
            return context.getString(R.string.login_status_pending);
        }

        return context.getString(R.string.login_status_not_set);
    }

    private static String getDisplayId(Context context, SettingsData.BaseSettingsData settings) {
        if (settings == null || settings.mId == null || settings.mId.trim().length() == 0) {
            if (settings instanceof SettingsData.TvingSettingsData) {
                SettingsData.TvingSettingsData tvingSettings = (SettingsData.TvingSettingsData) settings;
                if (tvingSettings.mSessionCookie != null && tvingSettings.mSessionCookie.trim().length() > 0) {
                    return context.getString(R.string.login_account_session);
                }
            }
            return "-";
        }

        return settings.mId.trim();
    }

    private static String getTvingAccountType(Context context) {
        return context.getString(R.string.login_account_type_web);
    }

    private static String getEnabledText(Context context, SettingsData.BaseSettingsData settings) {
        return settings != null && settings.mEnable
                ? context.getString(R.string.service_enabled_yes)
                : context.getString(R.string.service_enabled_no);
    }

    private static String getQualityText(Context context, SettingsData.BaseSettingsData settings) {
        if (settings instanceof SettingsData.PooqSettingsData) {
            SettingsData.PooqQualityType qualityType = ((SettingsData.PooqSettingsData) settings).mQualityType;
            if (qualityType == null) {
                qualityType = SettingsData.PooqQualityType.Mobile;
            }

            switch (qualityType) {
                case SD:
                    return context.getString(R.string.sd);
                case HD:
                    return context.getString(R.string.hd);
                case FHD:
                    return context.getString(R.string.fullhd);
                case Mobile:
                default:
                    return context.getString(R.string.mobile);
            }
        }

        if (settings instanceof SettingsData.TvingSettingsData) {
            SettingsData.TvingQualityType qualityType = ((SettingsData.TvingSettingsData) settings).mQualityType;
            if (qualityType == null) {
                qualityType = SettingsData.TvingQualityType.AUTO;
            }

            switch (qualityType) {
                case AUTO:
                    return context.getString(R.string.auto_quality);
                case SD:
                    return context.getString(R.string.sd);
                case HD:
                    return context.getString(R.string.hd);
                case FHD:
                    return context.getString(R.string.fullhd);
                case MD:
                default:
                    return context.getString(R.string.mobile);
            }
        }

        return "-";
    }

    private static String buildServiceSummary(Context context, SettingsData.BaseSettingsData settings, String accountType) {
        StringBuilder builder = new StringBuilder();

        builder.append(context.getString(R.string.service_enabled_label))
                .append(": ")
                .append(getEnabledText(context, settings));

        builder.append("\n")
                .append(context.getString(R.string.quality_label))
                .append(": ")
                .append(getQualityText(context, settings));

        builder.append("\n")
                .append(context.getString(R.string.login_saved_at_label))
                .append(": ")
                .append(formatStatusTime(settings != null ? settings.mLastSavedAt : 0L));

        builder.append("\n")
                .append(context.getString(R.string.login_status_label))
                .append(": ")
                .append(getStatusText(context, settings));

        if (accountType != null && accountType.length() > 0) {
            builder.append("\n")
                    .append(context.getString(R.string.login_account_type_label))
                    .append(": ")
                    .append(accountType);
        }

        builder.append("\n")
                .append(context.getString(R.string.login_account_label))
                .append(": ")
                .append(getDisplayId(context, settings));

        builder.append("\n")
                .append(context.getString(R.string.login_checked_at_label))
                .append(": ")
                .append(formatStatusTime(settings != null ? settings.mLastCheckedAt : 0L));

        return builder.toString();
    }

    // MainStepFragment
    public static class MainStepFragment extends GuidedStepSupportFragment {

        private String getStringById(int resourceId) {
            return this.getResources().getString(resourceId);
        }

        @Override
        @NonNull
        public Guidance onCreateGuidance(@NonNull Bundle savedInstanceState) {
            String title = getStringById(R.string.settings_title);
            String breadcrumb = getStringById(R.string.browse_title);
            String description = getStringById(R.string.settings_desc);
            Drawable icon = getActivity().getDrawable(R.drawable.settings_icon);

            return new Guidance(title, description, breadcrumb, icon);
        }

        @Override
        public void onCreateActions(@NonNull List<GuidedAction> actions,
                                    Bundle savedInstanceState) {

            addAction(getContext(), actions, GuidedId.Pooq.ordinal(),
                    getStringById(R.string.pooqsettings),
                    buildServiceSummary(getContext(), mSettings.mPooqSettings, null),
                    getActivity().getDrawable(R.drawable.wavve_icon_24));

            addAction(getContext(), actions, GuidedId.Tving.ordinal(),
                    getStringById(R.string.tvingsettings),
                    buildServiceSummary(getContext(), mSettings.mTvingSettings, getTvingAccountType(getContext())),
                    getActivity().getDrawable(R.drawable.tving_icon_24));

        }

        @Override
        public void onGuidedActionClicked(GuidedAction action) {
            FragmentManager fm = getFragmentManager();

            if (action.getId() == GuidedId.Pooq.ordinal()) {
                GuidedStepSupportFragment.add(fm, new PooqStepFragment());
            } else if (action.getId() == GuidedId.Tving.ordinal()) {
                GuidedStepSupportFragment.add(fm, new TvingStepFragment());
            }
        }
    }

    // PooqStepFragment
    public static class PooqStepFragment extends GuidedStepSupportFragment {

        private boolean mValidatingLogin = false;

        private String getStringById(int resourceId) {
            return this.getResources().getString(resourceId);
        }

        private void finishWithSettingsResult() {
            Intent intent = new Intent();
            Gson gson = new Gson();
            intent.putExtra(getStringById(R.string.SETTINGSDATA_STR), gson.toJson(mSettings));
            getActivity().setResult(Utils.Code.PooqSave.ordinal(), intent);
            getActivity().finishAfterTransition();
        }

        private void commitPooqSettings(boolean enable, String id, String password, String statusText) {

            mSettings.mPooqSettings.mEnable = enable;
            mSettings.mPooqSettings.mId = id;
            mSettings.mPooqSettings.mPassword = password;
            mSettings.mPooqSettings.mLastSavedAt = System.currentTimeMillis();
            mSettings.mPooqSettings.mLastCheckedAt = System.currentTimeMillis();
            mSettings.mPooqSettings.mLastStatus = statusText;

            if (mSettings.mPooqSettings.mQualityType == null) {
                mSettings.mPooqSettings.mQualityType = SettingsData.PooqQualityType.Mobile;
            }

            finishWithSettingsResult();
        }

        @Override
        @NonNull
        public Guidance onCreateGuidance(@NonNull Bundle savedInstanceState) {
            String title = getStringById(R.string.pooqsettings);
            String breadcrumb = getStringById(R.string.browse_title);
            String description = getStringById(R.string.wavve_setdesc) + "\n\n" +
                    buildServiceSummary(getContext(), mSettings.mPooqSettings, null);
            Drawable icon = getActivity().getDrawable(R.drawable.wavve_icon);

            return new Guidance(title, description, breadcrumb, icon);
        }

        @Override
        public void onCreateActions(@NonNull List<GuidedAction> actions,
                                    Bundle savedInstanceState) {

            SettingsData.PooqSettingsData pooqSettings = mSettings.mPooqSettings;

            boolean enabled = pooqSettings.mEnable;
            if (!enabled && pooqSettings.mLastSavedAt <= 0L) {
                enabled = hasText(pooqSettings.mId) && hasText(pooqSettings.mPassword);
            }
            addCheckedAction(getContext(), actions, GuidedId.PooqEnable.ordinal(),
                    getStringById(R.string.channel_enable), "", enabled);

            String id = pooqSettings.mId == null ? "" : pooqSettings.mId;
            String pw = pooqSettings.mPassword == null ? "" : pooqSettings.mPassword;

            addEditableAction(getContext(), actions, GuidedId.PooqId.ordinal(),
                    getStringById(R.string.id), id, InputType.TYPE_CLASS_TEXT);

            addEditablePasswordAction(getContext(), actions, GuidedId.PooqPw.ordinal(),
                    getStringById(R.string.password), "", pw);

            ArrayList<GuidedAction> qualityList = new ArrayList<>();

            qualityList.add(new GuidedAction.Builder(getContext()).
                    title(getStringById(R.string.mobile)).id(GuidedId.PooqMobile.ordinal()).build());
            qualityList.add(new GuidedAction.Builder(getContext()).
                    title(getStringById(R.string.sd)).id(GuidedId.PooqSD.ordinal()).build());
            qualityList.add(new GuidedAction.Builder(getContext()).
                    title(getStringById(R.string.hd)).id(GuidedId.PooqHD.ordinal()).build());
            qualityList.add(new GuidedAction.Builder(getContext()).
                    title(getStringById(R.string.fullhd)).id(GuidedId.PooqFHD.ordinal()).build());

            addDropDownAction(getContext(), actions, GuidedId.PooqQuality.ordinal(),
                    getStringById(R.string.quality_set), "", qualityList);

            addAction(getContext(), actions, GuidedId.PooqLogout.ordinal(),
                    getStringById(R.string.logout),
                    getStringById(R.string.logout_desc));
        }

        @Override
        public void onCreateButtonActions(@NonNull List<GuidedAction> actions, Bundle savedInstanceState) {
            super.onCreateButtonActions(actions, savedInstanceState);

            addAction(getContext(), actions, GuidedId.PooqSave.ordinal(), getStringById(R.string.set_save), "");
        }

        @Override
        public void onGuidedActionClicked(GuidedAction action) {

            if (action.getId() == GuidedId.PooqLogout.ordinal()) {
                clearBaseSettings(getContext(), mSettings.mPooqSettings);
                if (mSettings.mPooqSettings.mQualityType == null) {
                    mSettings.mPooqSettings.mQualityType = SettingsData.PooqQualityType.Mobile;
                }
                finishWithSettingsResult();
            } else if (action.getId() == GuidedId.PooqSave.ordinal()) {

                Boolean enable = findActionById(GuidedId.PooqEnable.ordinal()).isChecked();
                String id = getEditableActionText(findActionById(GuidedId.PooqId.ordinal())).trim();
                String password = getEditableActionText(findActionById(GuidedId.PooqPw.ordinal())).trim();

                if (enable && (!hasText(id) || !hasText(password))) {
                    Utils.showToast(getContext(), R.string.input_error);
                    return;
                }

                if (enable && hasText(id) && hasText(password)) {
                    if (mValidatingLogin) {
                        return;
                    }

                    mValidatingLogin = true;
                    new ValidateWavveLoginTask(getContext(), enable, id, password).execute();
                    return;
                }

                mSettings.mPooqSettings.mEnable = enable;
                mSettings.mPooqSettings.mId = id;
                mSettings.mPooqSettings.mPassword = password;
                mSettings.mPooqSettings.mLastSavedAt = System.currentTimeMillis();
                mSettings.mPooqSettings.mLastCheckedAt = 0L;
                mSettings.mPooqSettings.mLastStatus = getStringById(R.string.login_status_not_set);

                if (mSettings.mPooqSettings.mQualityType == null)
                    mSettings.mPooqSettings.mQualityType = SettingsData.PooqQualityType.Mobile;

                finishWithSettingsResult();
            }
        }

        @Override
        public boolean onSubGuidedActionClicked(GuidedAction action) {

            if (action.getId() == GuidedId.PooqMobile.ordinal()) {
                mSettings.mPooqSettings.mQualityType = SettingsData.PooqQualityType.Mobile;
            } else if (action.getId() == GuidedId.PooqSD.ordinal()) {
                mSettings.mPooqSettings.mQualityType = SettingsData.PooqQualityType.SD;
            } else if (action.getId() == GuidedId.PooqHD.ordinal()) {
                mSettings.mPooqSettings.mQualityType = SettingsData.PooqQualityType.HD;
            } else if (action.getId() == GuidedId.PooqFHD.ordinal()) {
                mSettings.mPooqSettings.mQualityType = SettingsData.PooqQualityType.FHD;
            }

            Utils.showToast(getContext(), mSettings.mPooqSettings.mQualityType.toString() + " " + getStringById(R.string.select));

            return true;
        }

        private class ValidateWavveLoginTask extends AsyncTask<Void, Void, Boolean> {

            private final Context appContext;
            private final boolean enable;
            private final String id;
            private final String password;

            ValidateWavveLoginTask(Context context, boolean enable, String id, String password) {
                this.appContext = context.getApplicationContext();
                this.enable = enable;
                this.id = id;
                this.password = password;
            }

            @Override
            protected Boolean doInBackground(Void... voids) {
                return PooqSiteProcessor.fetchWavveCredential(appContext, id, password).length() > 0;
            }

            @Override
            protected void onPostExecute(Boolean success) {
                mValidatingLogin = false;

                if (!isAdded() || getContext() == null) {
                    return;
                }

                if (!success) {
                    Utils.showToast(getContext(), R.string.login_invalid_credentials);
                    return;
                }

                commitPooqSettings(enable, id, password, getStringById(R.string.login_status_ok));
            }
        }
    }

    // TvingStepFragment
    public static class TvingStepFragment extends GuidedStepSupportFragment {

        private static final int REQUEST_TVING_WEB_LOGIN = 1001;

        private String getStringById(int resourceId) {
            return this.getResources().getString(resourceId);
        }

        private void finishWithSettingsResult() {
            Intent intent = new Intent();
            Gson gson = new Gson();
            intent.putExtra(getStringById(R.string.SETTINGSDATA_STR), gson.toJson(mSettings));
            getActivity().setResult(Utils.Code.TvingSave.ordinal(), intent);
            getActivity().finishAfterTransition();
        }

        @Override
        @NonNull
        public Guidance onCreateGuidance(@NonNull Bundle savedInstanceState) {
            String title = getStringById(R.string.tvingsettings);
            String breadcrumb = getStringById(R.string.browse_title);
            String description = getStringById(R.string.tving_setdesc) + "\n\n" +
                    buildServiceSummary(getContext(), mSettings.mTvingSettings, getTvingAccountType(getContext()));
            Drawable icon = getActivity().getDrawable(R.drawable.tving_icon);

            return new Guidance(title, description, breadcrumb, icon);
        }

        @Override
        public void onCreateActions(@NonNull List<GuidedAction> actions,
                                    Bundle savedInstanceState) {

            SettingsData.TvingSettingsData tvingSettings = mSettings.mTvingSettings;

            boolean enabled = tvingSettings.mEnable;
            if (!enabled && tvingSettings.mLastSavedAt <= 0L) {
                enabled = hasText(tvingSettings.mSessionCookie);
            }
            addCheckedAction(getContext(), actions, GuidedId.TvingEnable.ordinal(),
                    getStringById(R.string.channel_enable), "", enabled);

            addAction(getContext(), actions, GuidedId.TvingWebLogin.ordinal(),
                    getStringById(R.string.tving_web_login),
                    getStringById(R.string.tving_web_login_desc));

            ArrayList<GuidedAction> qualityList = new ArrayList<>();

            qualityList.add(new GuidedAction.Builder(getContext()).
                    title(getStringById(R.string.auto_quality)).id(GuidedId.TvingAuto.ordinal()).build());
            qualityList.add(new GuidedAction.Builder(getContext()).
                    title(getStringById(R.string.mobile)).id(GuidedId.TvingMD.ordinal()).build());
            qualityList.add(new GuidedAction.Builder(getContext()).
                    title(getStringById(R.string.sd)).id(GuidedId.TvingSD.ordinal()).build());
            qualityList.add(new GuidedAction.Builder(getContext()).
                    title(getStringById(R.string.hd)).id(GuidedId.TvingHD.ordinal()).build());
            qualityList.add(new GuidedAction.Builder(getContext()).
                    title(getStringById(R.string.fullhd)).id(GuidedId.TvingFHD.ordinal()).build());

            addDropDownAction(getContext(), actions, GuidedId.TvingQuality.ordinal(),
                    getStringById(R.string.quality_set), "", qualityList);

            addAction(getContext(), actions, GuidedId.TvingLogout.ordinal(),
                    getStringById(R.string.logout),
                    getStringById(R.string.logout_desc));
        }

        @Override
        public void onCreateButtonActions(@NonNull List<GuidedAction> actions, Bundle savedInstanceState) {
            super.onCreateButtonActions(actions, savedInstanceState);

            addAction(getContext(), actions, GuidedId.TvingSave.ordinal(), getStringById(R.string.set_save), "");
        }

        @Override
        public void onGuidedActionClicked(GuidedAction action) {

            if (action.getId() == GuidedId.TvingWebLogin.ordinal()) {
                Intent intent = new Intent(getActivity(), TvingLoginActivity.class);
                startActivityForResult(intent, REQUEST_TVING_WEB_LOGIN);
            } else if (action.getId() == GuidedId.TvingLogout.ordinal()) {
                clearTvingSettings(getContext(), mSettings.mTvingSettings);
                TvingAuthUtils.clearWebCookies();
                finishWithSettingsResult();
            } else if (action.getId() == GuidedId.TvingSave.ordinal()) {

                boolean enable = findActionById(GuidedId.TvingEnable.ordinal()).isChecked();
                boolean hasSession = mSettings.mTvingSettings.mSessionCookie != null &&
                        mSettings.mTvingSettings.mSessionCookie.trim().length() > 0;

                if (enable && !hasSession) {
                    Utils.showToast(getContext(), R.string.tving_web_login_required);
                    return;
                }

                mSettings.mTvingSettings.mEnable = enable && hasSession;
                mSettings.mTvingSettings.mCJOneId = false;
                mSettings.mTvingSettings.mLastSavedAt = System.currentTimeMillis();

                if (hasSession) {
                    mSettings.mTvingSettings.mLastStatus = getStringById(R.string.login_status_ok);
                    mSettings.mTvingSettings.mLastCheckedAt = System.currentTimeMillis();
                } else {
                    mSettings.mTvingSettings.mLastStatus = getStringById(R.string.login_status_not_set);
                    mSettings.mTvingSettings.mLastCheckedAt = 0L;
                }

                if (mSettings.mTvingSettings.mQualityType == null) {
                    mSettings.mTvingSettings.mQualityType = SettingsData.TvingQualityType.AUTO;
                }

                finishWithSettingsResult();
            }
        }

        @Override
        public void onActivityResult(int requestCode, int resultCode, Intent data) {
            super.onActivityResult(requestCode, resultCode, data);

            if (requestCode != REQUEST_TVING_WEB_LOGIN || resultCode != Activity.RESULT_OK || data == null) {
                return;
            }

            String sessionCookie = data.getStringExtra(TvingLoginActivity.EXTRA_AUTH_COOKIE);
            if (sessionCookie == null || sessionCookie.trim().length() == 0) {
                return;
            }

            String displayId = data.getStringExtra(TvingLoginActivity.EXTRA_DISPLAY_ID);
            long now = System.currentTimeMillis();

            mSettings.mTvingSettings.mSessionCookie = sessionCookie;
            mSettings.mTvingSettings.mEnable = true;
            mSettings.mTvingSettings.mCJOneId = false;
            mSettings.mTvingSettings.mLastStatus = getStringById(R.string.login_status_ok);
            mSettings.mTvingSettings.mLastCheckedAt = now;
            mSettings.mTvingSettings.mLastSavedAt = now;

            if (displayId != null && displayId.trim().length() > 0) {
                mSettings.mTvingSettings.mId = displayId.trim();
            } else if (mSettings.mTvingSettings.mId == null || mSettings.mTvingSettings.mId.trim().length() == 0) {
                mSettings.mTvingSettings.mId = getStringById(R.string.login_account_session);
            }

            finishWithSettingsResult();
        }

        @Override
        public boolean onSubGuidedActionClicked(GuidedAction action) {

            if (action.getId() == GuidedId.TvingMD.ordinal()) {
                mSettings.mTvingSettings.mQualityType = SettingsData.TvingQualityType.MD;
            } else if (action.getId() == GuidedId.TvingAuto.ordinal()) {
                mSettings.mTvingSettings.mQualityType = SettingsData.TvingQualityType.AUTO;
            } else if (action.getId() == GuidedId.TvingSD.ordinal()) {
                mSettings.mTvingSettings.mQualityType = SettingsData.TvingQualityType.SD;
            } else if (action.getId() == GuidedId.TvingHD.ordinal()) {
                mSettings.mTvingSettings.mQualityType = SettingsData.TvingQualityType.HD;
            } else if (action.getId() == GuidedId.TvingFHD.ordinal()) {
                mSettings.mTvingSettings.mQualityType = SettingsData.TvingQualityType.FHD;
            }

            Utils.showToast(getContext(), mSettings.mTvingSettings.mQualityType.toString() + " " + getStringById(R.string.select));

            return true;
        }
    }

    // OksusuStepFragment
    public static class OksusuStepFragment extends GuidedStepSupportFragment {

        private String getStringById(int resourceId) {
            return this.getResources().getString(resourceId);
        }

        @Override
        @NonNull
        public Guidance onCreateGuidance(@NonNull Bundle savedInstanceState) {
            String title = getStringById(R.string.oksususettings);
            String breadcrumb = getStringById(R.string.browse_title);
            String description = getStringById(R.string.oksusu_setdesc) + "\n\n" +
                    buildServiceSummary(getContext(), mSettings.mOksusuSettings, null);
            Drawable icon = getActivity().getDrawable(R.drawable.oksusu_icon);

            return new Guidance(title, description, breadcrumb, icon);
        }

        @Override
        public void onCreateActions(@NonNull List<GuidedAction> actions,
                                    Bundle savedInstanceState) {

            SettingsData.OksusuSettingsData oksusuSettings = mSettings.mOksusuSettings;

            boolean enabled = oksusuSettings.mEnable;
            addCheckedAction(getContext(), actions, GuidedId.OksusuEnable.ordinal(),
                    getStringById(R.string.channel_enable), "", enabled);

            String oksusuId = oksusuSettings.mId == null ? "" : oksusuSettings.mId;
            String oksusuPw = oksusuSettings.mPassword == null ? "" : oksusuSettings.mPassword;

            addEditableAction(getContext(), actions, GuidedId.OksusuId.ordinal(),
                    getStringById(R.string.id), oksusuId, InputType.TYPE_CLASS_TEXT);

            addEditablePasswordAction(getContext(), actions, GuidedId.OksusuPw.ordinal(),
                    getStringById(R.string.password), "", oksusuPw);

            ArrayList<GuidedAction> qualityList = new ArrayList<>();

            qualityList.add(new GuidedAction.Builder(getContext()).
                    title(getStringById(R.string.auto)).id(GuidedId.OksusuAuto.ordinal()).build());
            qualityList.add(new GuidedAction.Builder(getContext()).
                    title(getStringById(R.string.fullhd)).id(GuidedId.OksusuFullHd.ordinal()).build());
            qualityList.add(new GuidedAction.Builder(getContext()).
                    title(getStringById(R.string.hd)).id(GuidedId.OksusuHd.ordinal()).build());
            qualityList.add(new GuidedAction.Builder(getContext()).
                    title(getStringById(R.string.sd)).id(GuidedId.OksusuSd.ordinal()).build());

            addDropDownAction(getContext(), actions, GuidedId.OksusuQuality.ordinal(),
                    getStringById(R.string.quality_set), "", qualityList);
        }

        @Override
        public void onCreateButtonActions(@NonNull List<GuidedAction> actions, Bundle savedInstanceState) {
            super.onCreateButtonActions(actions, savedInstanceState);

            addAction(getContext(), actions, GuidedId.OksusuSave.ordinal(), getStringById(R.string.set_save), "");
        }

        @Override
        public void onGuidedActionClicked(GuidedAction action) {

            if (action.getId() == GuidedId.OksusuSave.ordinal()) {

                Boolean enable = findActionById(GuidedId.OksusuEnable.ordinal()).isChecked();
                String id = findActionById(GuidedId.OksusuId.ordinal()).getDescription().toString();
                String password = findActionById(GuidedId.OksusuPw.ordinal()).getEditDescription().toString();

                if (id == null || id.length() == 0 || password == null || password.length() == 0) {
                    Utils.showToast(getContext(), R.string.input_error);
                    return;
                }

                mSettings.mOksusuSettings.mEnable = enable;
                mSettings.mOksusuSettings.mId = id;
                mSettings.mOksusuSettings.mPassword = password;
                mSettings.mOksusuSettings.mLastSavedAt = System.currentTimeMillis();
                mSettings.mOksusuSettings.mLastStatus = getStringById(R.string.login_status_pending);

                if (mSettings.mOksusuSettings.mQualityType == null)
                    mSettings.mOksusuSettings.mQualityType = SettingsData.OksusuQualityType.AUTO;

                Intent intent = new Intent();

                Gson gson = new Gson();
                String myJson = gson.toJson(mSettings);
                intent.putExtra(getStringById(R.string.SETTINGSDATA_STR), myJson);

                getActivity().setResult(Utils.Code.OksusuSave.ordinal(), intent);
                getActivity().finishAfterTransition();
            }
        }

        @Override
        public boolean onSubGuidedActionClicked(GuidedAction action) {

            if (action.getId() == GuidedId.OksusuAuto.ordinal()) {
                mSettings.mOksusuSettings.mQualityType = SettingsData.OksusuQualityType.AUTO;
            } else if (action.getId() == GuidedId.OksusuFullHd.ordinal()) {
                mSettings.mOksusuSettings.mQualityType = SettingsData.OksusuQualityType.FullHD;
            } else if (action.getId() == GuidedId.OksusuHd.ordinal()) {
                mSettings.mOksusuSettings.mQualityType = SettingsData.OksusuQualityType.HD;
            } else if (action.getId() == GuidedId.OksusuSd.ordinal()) {
                mSettings.mOksusuSettings.mQualityType = SettingsData.OksusuQualityType.SD;
            }

            Utils.showToast(getContext(), mSettings.mOksusuSettings.mQualityType.toString() + " " + getStringById(R.string.select));

            return true;
        }
    }

}
