package com.ksi.alltv;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Build;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.JsonObject;

public class TvingLoginActivity extends AppCompatActivity {

    public static final String EXTRA_AUTH_COOKIE = "tving_auth_cookie";
    public static final String EXTRA_DISPLAY_ID = "tving_display_id";

    private static final String PLAYER_URL = "https://www.tving.com/player";
    private static final String LOGIN_URL = "https://www.tving.com/account/login?returnUrl=https%3A%2F%2Fwww.tving.com%2Fplayer";

    private final Handler mHandler = new Handler(Looper.getMainLooper());

    private WebView mWebView;
    private ProgressBar mProgressBar;
    private TextView mStatusView;

    private boolean mCompleted = false;
    private boolean mValidationInProgress = false;
    private boolean mRecoveredMissingPage = false;
    private String mLastValidatedCookie = "";

    private final Runnable mCookieWatcher = new Runnable() {
        @Override
        public void run() {
            if (!mCompleted) {
                attemptCompleteLogin();
                mHandler.postDelayed(this, 1500L);
            }
        }
    };

    private String getStringById(int resourceId) {
        return getResources().getString(resourceId);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tving_login);

        mWebView = findViewById(R.id.tving_login_webview);
        mProgressBar = findViewById(R.id.tving_login_progress);
        mStatusView = findViewById(R.id.tving_login_status);

        setupWebView();
        mStatusView.setText(getStringById(R.string.tving_web_login_progress));
        mWebView.loadUrl(LOGIN_URL);
        mHandler.postDelayed(mCookieWatcher, 1200L);
    }

    @Override
    protected void onDestroy() {
        mHandler.removeCallbacksAndMessages(null);

        if (mWebView != null) {
            mWebView.stopLoading();
            mWebView.destroy();
            mWebView = null;
        }

        super.onDestroy();
    }

    private void setupWebView() {
        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            cookieManager.setAcceptThirdPartyCookies(mWebView, true);
        }

        WebSettings settings = mWebView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setUserAgentString(getStringById(R.string.USERAGENT));

        CookieManager.getInstance().flush();

        mWebView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                mProgressBar.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
            }
        });

        mWebView.setWebViewClient(new WebViewClient() {
            @Override
            public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse errorResponse) {
                super.onReceivedHttpError(view, request, errorResponse);

                if (request == null || !request.isForMainFrame() || errorResponse == null) {
                    return;
                }

                if (errorResponse.getStatusCode() == 404) {
                    recoverMissingLoginPage();
                }
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (isMissingPageUrl(url)) {
                    recoverMissingLoginPage();
                    return;
                }
                attemptCompleteLogin();
            }
        });
    }

    private boolean isMissingPageUrl(String url) {
        if (url == null) {
            return false;
        }

        return url.contains("/account/login/select") ||
                url.contains("/not-found") ||
                url.contains("/error");
    }

    private void recoverMissingLoginPage() {
        if (mRecoveredMissingPage || mWebView == null) {
            return;
        }

        mRecoveredMissingPage = true;
        mStatusView.setText(getStringById(R.string.tving_web_login_progress));
        mWebView.loadUrl(LOGIN_URL);
    }

    private void attemptCompleteLogin() {
        if (mCompleted || mValidationInProgress) {
            return;
        }

        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.flush();

        String authCookie = TvingAuthUtils.buildAuthCookie(
                cookieManager.getCookie("https://www.tving.com"),
                cookieManager.getCookie(PLAYER_URL),
                cookieManager.getCookie("https://user.tving.com"),
                cookieManager.getCookie("https://api.tving.com"));

        if (!TvingAuthUtils.hasSessionToken(authCookie) || authCookie.equals(mLastValidatedCookie)) {
            return;
        }

        mLastValidatedCookie = authCookie;
        mValidationInProgress = true;
        mProgressBar.setVisibility(View.VISIBLE);
        mStatusView.setText(getStringById(R.string.tving_web_login_checking));

        new Thread(new Runnable() {
            @Override
            public void run() {
                JsonObject userInfo = TvingAuthUtils.fetchUserInfo(authCookie, getStringById(R.string.USERAGENT));
                boolean loggedIn = TvingAuthUtils.isLoggedIn(userInfo);
                String displayId = TvingAuthUtils.extractDisplayId(userInfo);

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        mValidationInProgress = false;

                        if (isFinishing() || isDestroyed()) {
                            return;
                        }

                        if (!loggedIn) {
                            mProgressBar.setVisibility(View.GONE);
                            mStatusView.setText(getStringById(R.string.tving_web_login_progress));
                            return;
                        }

                        mCompleted = true;

                        Intent resultIntent = new Intent();
                        resultIntent.putExtra(EXTRA_AUTH_COOKIE, authCookie);
                        resultIntent.putExtra(EXTRA_DISPLAY_ID, displayId);

                        setResult(RESULT_OK, resultIntent);
                        finish();
                    }
                });
            }
        }).start();
    }
}
