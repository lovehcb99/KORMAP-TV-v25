package com.ksi.alltv;

import android.util.Base64;

import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.TimeZone;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public final class TvingPlaybackUtils {

    private static final long TVING_KEY_SLOT_DIVISOR = 10000000L;
    private static final Charset ASCII = Charset.forName("US-ASCII");

    private TvingPlaybackUtils() {
    }

    public static PlaybackInfo decryptPlaybackInfo(String mediaCode, String encryptedBroadUrl, String serverTime) {

        if (mediaCode == null || mediaCode.trim().length() == 0 ||
                encryptedBroadUrl == null || encryptedBroadUrl.trim().length() == 0) {
            return null;
        }

        byte[] encryptedBytes;
        try {
            encryptedBytes = Base64.decode(encryptedBroadUrl, Base64.DEFAULT);
        } catch (Exception ex) {
            return null;
        }

        if (encryptedBytes == null || encryptedBytes.length == 0 || encryptedBytes.length % 8 != 0) {
            return null;
        }

        for (Long keySlot : buildKeySlots(serverTime)) {
            PlaybackInfo playbackInfo = decryptWithKeySlot(mediaCode, encryptedBytes, keySlot);
            if (playbackInfo != null) {
                return playbackInfo;
            }
        }

        return null;
    }

    private static PlaybackInfo decryptWithKeySlot(String mediaCode, byte[] encryptedBytes, long keySlot) {
        try {
            String channelKey = mediaCode.length() > 3 ? mediaCode.substring(3) : mediaCode;
            String key = String.format(Locale.US, "cjhv*tving**good/%s/%03d", channelKey, keySlot);

            Cipher cipher = Cipher.getInstance("DESede/ECB/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(key.getBytes(ASCII), "DESede"));

            String decrypted = trimControlCharacters(new String(cipher.doFinal(encryptedBytes), ASCII));
            if (!isPlayablePayload(decrypted)) {
                return null;
            }

            return buildPlaybackInfo(decrypted);
        } catch (Exception ex) {
            return null;
        }
    }

    private static LinkedHashSet<Long> buildKeySlots(String serverTime) {
        LinkedHashSet<Long> slots = new LinkedHashSet<>();

        long currentSlot = (System.currentTimeMillis() / 1000L) / TVING_KEY_SLOT_DIVISOR;
        addSlotVariants(slots, currentSlot);

        long serverSlot = parseServerTimeSlot(serverTime);
        if (serverSlot >= 0) {
            addSlotVariants(slots, serverSlot);
        }

        return slots;
    }

    private static void addSlotVariants(LinkedHashSet<Long> slots, long slot) {
        if (slot < 0) {
            return;
        }

        slots.add(slot);
        slots.add(slot - 1L);
        slots.add(slot + 1L);
    }

    private static long parseServerTimeSlot(String serverTime) {
        if (serverTime == null || serverTime.trim().length() != 14) {
            return -1L;
        }

        try {
            SimpleDateFormat format = new SimpleDateFormat("yyyyMMddHHmmss", Locale.US);
            format.setLenient(false);
            format.setTimeZone(TimeZone.getTimeZone("Asia/Seoul"));
            Date parsed = format.parse(serverTime);
            if (parsed == null) {
                return -1L;
            }
            return (parsed.getTime() / 1000L) / TVING_KEY_SLOT_DIVISOR;
        } catch (Exception ex) {
            return -1L;
        }
    }

    private static String trimControlCharacters(String text) {
        if (text == null) {
            return "";
        }

        int end = text.length();
        while (end > 0 && text.charAt(end - 1) <= 0x1f) {
            end -= 1;
        }

        return text.substring(0, end).trim();
    }

    private static boolean isPlayablePayload(String payload) {
        return payload != null &&
                (payload.startsWith("https://") || payload.startsWith("http://")) &&
                payload.contains("?") &&
                payload.contains("Policy=") &&
                payload.contains("Signature=") &&
                payload.contains("Key-Pair-Id=");
    }

    private static PlaybackInfo buildPlaybackInfo(String decryptedPayload) {
        int queryIndex = decryptedPayload.indexOf('?');
        if (queryIndex < 0) {
            return null;
        }

        String videoUrl = decryptedPayload.substring(0, queryIndex).trim();
        String queryString = decryptedPayload.substring(queryIndex + 1).trim();

        if (videoUrl.length() == 0 || queryString.length() == 0) {
            return null;
        }

        String[] queryParts = queryString.split("&");
        ArrayList<String> cookieParts = new ArrayList<>();

        for (String queryPart : queryParts) {
            String trimmed = queryPart == null ? "" : queryPart.trim();
            if (trimmed.length() == 0) {
                continue;
            }
            cookieParts.add("CloudFront-" + trimmed);
        }

        if (cookieParts.isEmpty()) {
            return null;
        }

        StringBuilder cookieBuilder = new StringBuilder();
        for (int i = 0; i < cookieParts.size(); i++) {
            if (i > 0) {
                cookieBuilder.append("; ");
            }
            cookieBuilder.append(cookieParts.get(i));
        }

        return new PlaybackInfo(videoUrl, cookieBuilder.toString());
    }

    public static final class PlaybackInfo {
        private final String mVideoUrl;
        private final String mVideoCookie;

        PlaybackInfo(String videoUrl, String videoCookie) {
            mVideoUrl = videoUrl;
            mVideoCookie = videoCookie;
        }

        public String getVideoUrl() {
            return mVideoUrl;
        }

        public String getVideoCookie() {
            return mVideoCookie;
        }
    }
}
