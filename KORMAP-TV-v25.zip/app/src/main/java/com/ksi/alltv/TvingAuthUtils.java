package com.ksi.alltv;

import android.os.Build;
import android.webkit.CookieManager;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

public final class TvingAuthUtils {

    private static final String API_KEY = "1e7952d0917d6aab1f0293a063697610";
    private static final String[] COOKIE_NAMES = {
            "_tving_token",
            "authToken",
            "_auth_token",
            "accessToken",
            "refreshToken",
            "TVING_SESSION",
            "TVING_LOGIN_DEVICE_UUID",
            "_abck",
            "bm_sz"
    };
    private static final String[] DISPLAY_ID_KEYS = {
            "loginId",
            "login_id",
            "tvingId",
            "tving_id",
            "emailId",
            "email_id",
            "email",
            "userId",
            "user_id",
            "id",
            "custId",
            "cust_id"
    };

    private TvingAuthUtils() {
    }

    public static void clearWebCookies() {
        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            cookieManager.removeAllCookies(null);
            cookieManager.removeSessionCookies(null);
            cookieManager.flush();
            return;
        }

        cookieManager.removeAllCookie();
        cookieManager.removeSessionCookie();
        cookieManager.removeExpiredCookie();
    }

    public static String buildAuthCookie(String... rawCookieHeaders) {
        LinkedHashMap<String, String> cookieMap = new LinkedHashMap<>();

        for (String rawCookieHeader : rawCookieHeaders) {
            mergeCookieHeader(cookieMap, rawCookieHeader);
        }

        if (cookieMap.isEmpty()) {
            return "";
        }

        ArrayList<String> cookiePairs = new ArrayList<>();
        for (Map.Entry<String, String> entry : cookieMap.entrySet()) {
            cookiePairs.add(entry.getKey() + "=" + entry.getValue());
        }

        return joinCookiePairs(cookiePairs);
    }

    public static String normalizeAuthCookie(String rawCookieHeader) {
        return buildAuthCookie(rawCookieHeader);
    }

    public static boolean hasSessionToken(String authCookie) {
        return getCookieValue(authCookie, "_tving_token").length() > 0 ||
                getCookieValue(authCookie, "authToken").length() > 0 ||
                getCookieValue(authCookie, "_auth_token").length() > 0 ||
                getCookieValue(authCookie, "accessToken").length() > 0;
    }

    public static void applyApiHeaders(HttpRequest request, String authCookie) {
        if (request == null || authCookie == null || authCookie.trim().length() == 0) {
            return;
        }

        request.header("Cookie", authCookie);

        String authToken = getCookieValue(authCookie, "authToken");
        if (authToken.length() == 0) {
            authToken = getCookieValue(authCookie, "_auth_token");
        }
        if (authToken.length() > 0) {
            request.header("Auth-Token", authToken);
        }

        String accessToken = getCookieValue(authCookie, "accessToken");
        if (accessToken.length() > 0) {
            request.header("Access-Token", accessToken);
        }

        String bearerToken = getCookieValue(authCookie, "_tving_token");
        if (bearerToken.length() > 0) {
            request.header("Authorization", "Bearer " + bearerToken);
        }
    }

    public static JsonObject fetchUserInfo(String authCookie, String userAgent) {
        try {
            HttpRequest request = HttpRequest.get("https://api.tving.com/v2/user/info", true,
                    "screenCode", "CSSD0100",
                    "osCode", "CSOD0900",
                    "networkCode", "CSND0900",
                    "teleCode", "CSCD0900",
                    "apiKey", API_KEY)
                    .userAgent(userAgent)
                    .acceptJson();

            applyApiHeaders(request, authCookie);

            if (request == null || request.badRequest() || request.isBodyEmpty()) {
                return null;
            }

            return new JsonParser().parse(request.body()).getAsJsonObject();
        } catch (Exception ex) {
            return null;
        }
    }

    public static boolean isLoggedIn(JsonObject userInfo) {
        if (userInfo == null || !userInfo.has("header") || !userInfo.get("header").isJsonObject()) {
            return false;
        }

        JsonObject headerObject = userInfo.getAsJsonObject("header");
        if (!headerObject.has("status")) {
            return false;
        }

        try {
            return headerObject.get("status").getAsInt() == 200;
        } catch (Exception ex) {
            return "200".equals(headerObject.get("status").getAsString());
        }
    }

    public static String extractDisplayId(JsonObject userInfo) {
        if (userInfo == null) {
            return "";
        }

        for (String key : DISPLAY_ID_KEYS) {
            String value = findFirstString(userInfo, key);
            if (value.length() > 0 && !value.startsWith("http")) {
                return value;
            }
        }

        return "";
    }

    public static String getCookieValue(String authCookie, String cookieName) {
        if (authCookie == null || cookieName == null) {
            return "";
        }

        String[] cookiePairs = authCookie.split(";");
        for (String cookiePair : cookiePairs) {
            String trimmed = cookiePair == null ? "" : cookiePair.trim();
            if (!trimmed.startsWith(cookieName + "=")) {
                continue;
            }

            int separator = trimmed.indexOf('=');
            if (separator < 0 || separator + 1 >= trimmed.length()) {
                return "";
            }

            return trimmed.substring(separator + 1).trim();
        }

        return "";
    }

    private static void mergeCookieHeader(LinkedHashMap<String, String> cookieMap, String rawCookieHeader) {
        if (rawCookieHeader == null || rawCookieHeader.trim().length() == 0) {
            return;
        }

        String[] cookiePairs = rawCookieHeader.split(";");
        for (String cookiePair : cookiePairs) {
            String trimmed = cookiePair == null ? "" : cookiePair.trim();
            int separator = trimmed.indexOf('=');
            if (separator <= 0) {
                continue;
            }

            String cookieName = trimmed.substring(0, separator).trim();
            String cookieValue = trimmed.substring(separator + 1).trim();

            for (String allowedCookie : COOKIE_NAMES) {
                if (allowedCookie.equals(cookieName) && cookieValue.length() > 0) {
                    cookieMap.put(cookieName, cookieValue);
                    break;
                }
            }
        }
    }

    private static String joinCookiePairs(ArrayList<String> cookiePairs) {
        StringBuilder builder = new StringBuilder();

        for (int i = 0; i < cookiePairs.size(); i++) {
            if (i > 0) {
                builder.append("; ");
            }
            builder.append(cookiePairs.get(i));
        }

        return builder.toString();
    }

    private static String findFirstString(JsonElement element, String targetKey) {
        if (element == null || element.isJsonNull()) {
            return "";
        }

        if (element.isJsonObject()) {
            JsonObject object = element.getAsJsonObject();

            if (object.has(targetKey) && object.get(targetKey).isJsonPrimitive()) {
                String value = object.get(targetKey).getAsString().trim();
                if (value.length() > 0) {
                    return value;
                }
            }

            for (Map.Entry<String, JsonElement> entry : object.entrySet()) {
                String value = findFirstString(entry.getValue(), targetKey);
                if (value.length() > 0) {
                    return value;
                }
            }
        } else if (element.isJsonArray()) {
            JsonArray array = element.getAsJsonArray();
            for (JsonElement child : array) {
                String value = findFirstString(child, targetKey);
                if (value.length() > 0) {
                    return value;
                }
            }
        }

        return "";
    }
}
