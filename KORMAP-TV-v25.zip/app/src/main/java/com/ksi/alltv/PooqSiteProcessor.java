/*
 * MIT License
 *
 * Copyright (c) 2019 PYTHONKOR

 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:

 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.

 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

package com.ksi.alltv;

import android.content.Context;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;


public class PooqSiteProcessor extends SiteProcessor {

    private static final String TAG = PooqSiteProcessor.class.getSimpleName();
    private static final String WAVVE_UI_TYPE = "LN61";
    private static final String WAVVE_UI_PARENT = "FN0";
    private static final String WAVVE_BROADCAST_ID = "FN0_LN61_pc_none_free";
    private static final String WAVVE_DRM = "widevine";
    private static final String WAVVE_TARGET_AGE = "20";

    public PooqSiteProcessor(Context context) {
        super(context);
        mChannelDatas.clear();
    }

    @Override
    public boolean doProcess(SettingsData inSettingsData) {

        mQualityType = inSettingsData.mPooqSettings.mQualityType.ordinal();

        if (mAuthKey == null || mAuthKey.length() == 0)
            doLogin(inSettingsData);

        return getLiveTvList(inSettingsData);
    }

    @Override
    public boolean updateProcess() {
        return getEPGList();
    }

    private boolean getLiveTvList(SettingsData inSettingsData) {

        mQualityType = inSettingsData.mPooqSettings.mQualityType.ordinal();

        try {

            mChannelDatas.clear();
            mCategoryDatas.clear();

            JsonObject filterResponse = requestWavveChannelList("all", 0, 5);
            if (filterResponse == null) {
                return false;
            }

            JsonObject filterObject = filterResponse.getAsJsonObject("filter");
            JsonArray filterGroups = filterObject != null ? filterObject.getAsJsonArray("filterlist") : null;
            HashSet<String> addedChannelIds = new HashSet<>();

            if (filterGroups != null && filterGroups.size() > 0) {
                JsonArray filterItems = filterGroups.get(0).getAsJsonObject().getAsJsonArray("filter_item_list");

                for (JsonElement filterElement : filterItems) {
                    JsonObject filterItem = filterElement.getAsJsonObject();
                    String genreCode = extractGenreCode(filterItem.get("api_parameters").getAsString());

                    if (genreCode == null || genreCode.equals("all")) {
                        continue;
                    }

                    int categoryId = Integer.parseInt(genreCode);
                    String categoryName = Utils.removeQuote(filterItem.get("title").getAsString());

                    CategoryData ctData = new CategoryData();
                    ctData.setId(categoryId);
                    ctData.setTitle(categoryName);
                    mCategoryDatas.add(ctData);

                    JsonObject categoryResponse = requestWavveChannelList(genreCode, 0, 300);
                    if (categoryResponse == null) {
                        continue;
                    }

                    JsonObject cellTopList = categoryResponse.getAsJsonObject("cell_toplist");
                    JsonArray cellList = cellTopList != null ? cellTopList.getAsJsonArray("celllist") : null;

                    appendWavveChannelList(cellList, categoryId, addedChannelIds);
                }
            }

            if (mChannelDatas.isEmpty()) {
                CategoryData ctData = new CategoryData();
                ctData.setId(0);
                ctData.setTitle("전체");
                mCategoryDatas.add(ctData);

                JsonObject cellTopList = filterResponse.getAsJsonObject("cell_toplist");
                JsonArray cellList = cellTopList != null ? cellTopList.getAsJsonArray("celllist") : null;
                appendWavveChannelList(cellList, 0, addedChannelIds);
            }

            if (mChannelDatas.isEmpty()) {
                return false;
            }

        } catch (Exception ex) {
            mChannelDatas.clear();
            mCategoryDatas.clear();
            return false;
        } finally {
            if(!getEPGList())
                return false;
        }

        return true;
    }

    public boolean getEPGList() {

        Long ts = System.currentTimeMillis();
        String timestamp = ts.toString();

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:00");
        String startTime = sdf.format(new Date());

        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.HOUR_OF_DAY, 6);
        String endTime = sdf.format(calendar.getTime());

        // https://apis.pooq.co.kr/live/epgs?apikey=E5F3E0D30947AA5440556471321BB6D9
        // &device=pc
        // &partner=pooq
        // &region=kor
        // &targetage=auto
        // &credential=none
        // &pooqzone=none
        // &drm=wm
        // &genre=all
        // &startdatetime=2019-07-29+12:00
        // &enddatetime=2019-07-29+15:00
        // &offset=0&limit=100

        try {

            HttpRequest request = HttpRequest.get(getStringById(R.string.POOQ_EPG_URL), true,
                    "apikey", getStringById(R.string.POOQ_API_ACCESSKEY_STR),
                    "device", getStringById(R.string.PC_STR),
                    "partner", "pooq",
                    "region", "kor",
                    "targetage", "auto",
                    "credential", "none",
                    "pooqzone", "none",
                    "drm", "wm",
                    "genre", "all",
                    "startdatetime", startTime,
                    "enddatetime", endTime,
                    "offset", "0",
                    "limit", "100")
                    .userAgent(getStringById(R.string.USERAGENT));

            if(request == null || request.badRequest() || request.isBodyEmpty())
                return false;

            String resultJson = request.body();

            JsonParser jParser = new JsonParser();
            JsonArray jArray = jParser.parse(resultJson).getAsJsonObject().getAsJsonArray(getStringById(R.string.LIST_STR));

            // Channels
            for (JsonElement arr : jArray) {
                JsonObject channelObj = arr.getAsJsonObject();

                String serviceId = Utils.removeQuote(channelObj.get("channelid").getAsString());

                ChannelData channelData = null;

                for(int i=0; i<mChannelDatas.size(); i++) {
                    if(mChannelDatas.get(i).getId().equals(serviceId)) {
                        channelData = mChannelDatas.get(i);
                        break;
                    }
                }

                if(channelData == null) {
    //                Log.e(TAG, serviceId + ", " + channelName + " is not exist.");
                    continue;
                }

                JsonArray programs = channelObj.getAsJsonArray(getStringById(R.string.LIST_STR));

                ArrayList<EPGData> epgData = new ArrayList<>();

                for (JsonElement arr1 : programs) {
                    JsonObject programObj = arr1.getAsJsonObject();

                    String programName = Utils.removeHTMLTag(programObj.get("title").getAsString());
                    String stimeStr = Utils.removeQuote(programObj.get("starttime").getAsString());
                    String etimeStr = Utils.removeQuote(programObj.get("endtime").getAsString());

                    Date stime = new Date(0);
                    Date etime = new Date(0);
                    try {
                        stime = new SimpleDateFormat("yyyy-MM-dd HH:mm").parse(stimeStr);
                        etime = new SimpleDateFormat("yyyy-MM-dd HH:mm").parse(etimeStr);
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }

                    epgData.add(new EPGData(programName, stime, etime, false));
                }

                channelData.setEPG(epgData);
            }

        } catch (Exception ex) {
            return false;
        }

        return true;
    }

    private boolean doLogin(SettingsData inSettingsData) {

        mAuthKey = "";
        mQualityType = inSettingsData.mPooqSettings.mQualityType.ordinal();

        if (inSettingsData.mPooqSettings.mId == null || inSettingsData.mPooqSettings.mPassword == null)
            return false;

        if (inSettingsData.mPooqSettings.mId.trim().length() == 0 ||
                inSettingsData.mPooqSettings.mPassword.trim().length() == 0)
            return false;

        try {

            mAuthKey = fetchWavveCredential(getContext(),
                    inSettingsData.mPooqSettings.mId, inSettingsData.mPooqSettings.mPassword);

        } catch (Exception ex) {
            mAuthKey = "";
            return false;
        }

        return mAuthKey.length() > 0;
    }

    private JsonObject requestWavveChannelList(String genreCode, int offset, int limit) {

        HttpRequest request = HttpRequest.get(getStringById(R.string.POOQ_CHANNELLIST_URL), true,
                "apikey", getStringById(R.string.POOQ_API_ACCESSKEY_STR),
                "credential", getWavveCredential(),
                "device", getStringById(R.string.PC_STR),
                "partner", "pooq",
                "pooqzone", "none",
                "region", "kor",
                "drm", WAVVE_DRM,
                "targetage", WAVVE_TARGET_AGE,
                "contenttype", "channel",
                "isrecommend", "n",
                "WeekDay", "all",
                "uitype", WAVVE_UI_TYPE,
                "genre", genreCode,
                "type", "all",
                "offset", Integer.toString(offset),
                "limit", Integer.toString(limit),
                "broadcastid", WAVVE_BROADCAST_ID,
                "uiparent", WAVVE_UI_PARENT,
                "uirank", "0")
                .userAgent(getStringById(R.string.USERAGENT))
                .acceptJson();

        if (request == null || request.badRequest() || request.isBodyEmpty()) {
            return null;
        }

        return new JsonParser().parse(request.body()).getAsJsonObject();
    }

    private void appendWavveChannelList(JsonArray cellList, int categoryId, HashSet<String> addedChannelIds) {

        if (cellList == null) {
            return;
        }

        for (JsonElement cellElement : cellList) {
            JsonObject channelObject = cellElement.getAsJsonObject();
            String channelId = Utils.removeQuote(channelObject.get("contentid").getAsString());

            if (addedChannelIds.contains(channelId)) {
                continue;
            }

            addedChannelIds.add(channelId);

            JsonArray titleList = channelObject.getAsJsonArray("title_list");
            String channelName = titleList.size() > 0
                    ? Utils.removeQuote(titleList.get(0).getAsJsonObject().get("text").getAsString())
                    : channelId;
            String programName = titleList.size() > 1
                    ? Utils.removeQuote(titleList.get(1).getAsJsonObject().get("text").getAsString())
                    : "";

            ChannelData chData = new ChannelData();
            chData.setSiteType(Utils.SiteType.Pooq.ordinal());
            chData.setQualityType(mQualityType);
            chData.setAuthKey(mAuthKey);
            chData.setTitle(channelName);
            chData.setProgramName(programName);
            chData.setStillImageUrl(normalizeWavveImageUrl(channelObject.get("thumbnail").getAsString()));
            chData.setId(channelId);
            chData.setCategoryId(categoryId);
            chData.setAudioChannel(false);

            mChannelDatas.add(chData);
        }
    }

    private String normalizeWavveImageUrl(String imageUrl) {

        if (imageUrl == null || imageUrl.length() == 0 || imageUrl.equals("null")) {
            return "";
        }

        if (imageUrl.startsWith("http://") || imageUrl.startsWith("https://")) {
            return imageUrl;
        }

        return "https://" + imageUrl;
    }

    private String extractGenreCode(String apiParameters) {

        if (apiParameters == null || apiParameters.length() == 0) {
            return null;
        }

        int index = apiParameters.indexOf("genre=");
        if (index < 0) {
            return null;
        }

        String genreCode = apiParameters.substring(index + 6);
        int separator = genreCode.indexOf('&');
        if (separator >= 0) {
            genreCode = genreCode.substring(0, separator);
        }

        return genreCode;
    }

    private String getWavveCredential() {
        return (mAuthKey == null || mAuthKey.length() == 0) ? "none" : mAuthKey;
    }

    public static String fetchWavveCredential(Context context, String id, String password) {

        String credential = requestWavveCredential(context, id, password, "wavve");

        if (credential.length() == 0) {
            credential = requestWavveCredential(context, id, password, "general");
        }

        return credential;
    }

    private static String requestWavveCredential(Context context, String id, String password, String loginType) {

        JsonObject loginBody = new JsonObject();
        loginBody.addProperty("type", loginType);
        loginBody.addProperty("id", id);
        loginBody.addProperty("password", password);
        loginBody.addProperty("device", context.getString(R.string.PC_STR));

        HttpRequest postRequest = HttpRequest.post(context.getString(R.string.POOQ_LOGIN_URL), true)
                .userAgent(context.getString(R.string.USERAGENT))
                .acceptJson()
                .contentType(HttpRequest.CONTENT_TYPE_JSON, HttpRequest.CHARSET_UTF8)
                .send(loginBody.toString());

        if (postRequest == null || postRequest.badRequest() || postRequest.isBodyEmpty()) {
            return "";
        }

        JsonObject responseObject = new JsonParser().parse(postRequest.body()).getAsJsonObject();
        JsonElement credentialElement = responseObject.get("credential");

        if ((credentialElement == null || credentialElement.isJsonNull()) && responseObject.has("data")) {
            JsonObject dataObject = responseObject.getAsJsonObject("data");
            credentialElement = dataObject != null ? dataObject.get("credential") : null;
        }

        if (credentialElement == null || credentialElement.isJsonNull()) {
            return "";
        }

        return Utils.removeQuote(credentialElement.getAsString());
    }
}
