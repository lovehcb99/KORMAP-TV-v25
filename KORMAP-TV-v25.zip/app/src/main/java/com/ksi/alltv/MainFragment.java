/*
 * MIT License
 *
 * Copyright (c) 2019 PYTHONKOR

 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:

 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.

 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

package com.ksi.alltv;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import androidx.leanback.app.BrowseSupportFragment;
import androidx.leanback.widget.ArrayObjectAdapter;
import androidx.leanback.widget.HeaderItem;
import androidx.leanback.widget.ListRow;
import androidx.leanback.widget.ListRowPresenter;
import androidx.leanback.widget.OnItemViewClickedListener;
import androidx.leanback.widget.OnItemViewSelectedListener;
import androidx.leanback.widget.PageRow;
import androidx.leanback.widget.Presenter;
import androidx.leanback.widget.Row;
import androidx.leanback.widget.RowPresenter;
import androidx.fragment.app.Fragment;
import androidx.core.content.ContextCompat;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.orhanobut.hawk.Hawk;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;


public class MainFragment extends BrowseSupportFragment implements FetchChannelResultReceiver.Receiver,
        OnItemViewClickedListener, OnItemViewSelectedListener {

    private static final String TAG = MainFragment.class.getSimpleName();

    private final Handler mHandler = new Handler();
    private PicassoBackgroundManager mPicassoBackgroundManager = null;
    private Gson mGson = new Gson();

    private FetchChannelResultReceiver mChannelResultReceiver;
    private ArrayObjectAdapter mCategoryRowAdapter;

    private SettingsData mSettingsData = new SettingsData();

    private SpinnerFragment[] mSpinnerFragment = new SpinnerFragment[Utils.SiteType.values().length];

    private Timer mTimer;
    private String mUpdateTime;

    private boolean shouldShowPooqSection() {
        return true;
    }

    private boolean shouldShowTvingSection() {
        return true;
    }

    private boolean shouldFetchPooqSection() {
        return mSettingsData != null &&
                mSettingsData.mPooqSettings != null &&
                mSettingsData.mPooqSettings.mEnable &&
                hasText(mSettingsData.mPooqSettings.mId) &&
                hasText(mSettingsData.mPooqSettings.mPassword);
    }

    private boolean shouldFetchTvingSection() {
        return mSettingsData != null &&
                mSettingsData.mTvingSettings != null &&
                mSettingsData.mTvingSettings.mEnable &&
                hasText(mSettingsData.mTvingSettings.mSessionCookie);
    }

    private boolean shouldShowOksusuSection() {
        return false;
    }

    private boolean shouldFetchOksusuSection() {
        return false;
    }

    private boolean hasText(String value) {
        return value != null && value.trim().length() > 0;
    }

    private void normalizeServiceSettings() {
        if (mSettingsData == null) {
            mSettingsData = new SettingsData();
        }

        if (mSettingsData.mPooqSettings == null) {
            mSettingsData.mPooqSettings = mSettingsData.new PooqSettingsData();
        }
        if (mSettingsData.mTvingSettings == null) {
            mSettingsData.mTvingSettings = mSettingsData.new TvingSettingsData();
        }
        if (mSettingsData.mOksusuSettings == null) {
            mSettingsData.mOksusuSettings = mSettingsData.new OksusuSettingsData();
        }

        if (mSettingsData.mPooqSettings.mQualityType == null) {
            mSettingsData.mPooqSettings.mQualityType = SettingsData.PooqQualityType.SD;
        }
        boolean hasPooqCredentials = hasText(mSettingsData.mPooqSettings.mId) &&
                hasText(mSettingsData.mPooqSettings.mPassword);
        if (!hasPooqCredentials) {
            mSettingsData.mPooqSettings.mEnable = false;
        } else if (mSettingsData.mPooqSettings.mLastSavedAt <= 0L) {
            mSettingsData.mPooqSettings.mEnable = true;
        }

        if (mSettingsData.mTvingSettings.mQualityType == null) {
            mSettingsData.mTvingSettings.mQualityType = SettingsData.TvingQualityType.AUTO;
        }
        mSettingsData.mTvingSettings.mCJOneId = false;
        boolean hasTvingSession = hasText(mSettingsData.mTvingSettings.mSessionCookie);
        if (!hasTvingSession) {
            mSettingsData.mTvingSettings.mEnable = false;
        } else if (mSettingsData.mTvingSettings.mLastSavedAt <= 0L) {
            mSettingsData.mTvingSettings.mEnable = true;
        }

        mSettingsData.mOksusuSettings.mEnable = false;
    }

    private SettingsData.BaseSettingsData getBaseSettings(Utils.SiteType siteType) {
        switch (siteType) {
            case Pooq:
                return mSettingsData.mPooqSettings;
            case Tving:
                return mSettingsData.mTvingSettings;
            case Oksusu:
                return mSettingsData.mOksusuSettings;
            default:
                return null;
        }
    }

    private void persistSettingsData() {
        if (Hawk.contains(getStringById(R.string.SETTINGS_STR)) || mSettingsData != null) {
            Hawk.put(getStringById(R.string.SETTINGS_STR), mGson.toJson(mSettingsData));
        }
    }

    private void updateServiceStatus(Utils.SiteType siteType, String status) {
        SettingsData.BaseSettingsData settings = getBaseSettings(siteType);
        if (settings == null) {
            return;
        }

        settings.mLastStatus = status;
        settings.mLastCheckedAt = System.currentTimeMillis();
        persistSettingsData();
    }

    private void clearServiceSection(Utils.SiteType siteType) {
        AllTvBaseRowsSupportFragment.clearSiteData(siteType);

        Fragment fragment = getMainFragment();

        if (siteType == Utils.SiteType.Pooq && fragment instanceof PooqRowSupportFragment) {
            ((PooqRowSupportFragment) fragment).createRows();
        } else if (siteType == Utils.SiteType.Tving && fragment instanceof TvingRowSupportFragment) {
            ((TvingRowSupportFragment) fragment).createRows();
        }

        if (fragment instanceof FavoriteRowSupportFragment) {
            ((FavoriteRowSupportFragment) fragment).createRows();
        }
    }

    private void applyAuthKey(ArrayList<ChannelData> channels, String authKey) {
        AllTvBaseRowsSupportFragment.applyAuthKeyToChannels(channels, authKey);
    }

    private String getStringById(int resourceId) {
        return this.getResources().getString(resourceId);
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        initOnCreated();

        if (shouldFetchPooqSection()) {
            startServiceIntent(Utils.SiteType.Pooq);
        }
        if (shouldFetchTvingSection()) {
            startServiceIntent(Utils.SiteType.Tving);
        }
        if (shouldFetchOksusuSection()) {
            startServiceIntent(Utils.SiteType.Oksusu);
        }

    }

    private void initOnCreated() {

        Hawk.init(getContext())
                //.setEncryptionMethod(HawkBuilder.EncryptionMethod.HIGHEST)
                .build();

        if (Hawk.contains(getStringById(R.string.SETTINGS_STR))) {

            String settingsStr = Hawk.get(getStringById(R.string.SETTINGS_STR));

            mSettingsData = mGson.fromJson(settingsStr, SettingsData.class);
            normalizeServiceSettings();

            PooqRowSupportFragment.setEnable(mSettingsData.mPooqSettings.mEnable? Boolean.TRUE: Boolean.FALSE);
            PooqRowSupportFragment.setQualityType(mSettingsData.mPooqSettings.mQualityType);
            TvingRowSupportFragment.setEnable(mSettingsData.mTvingSettings.mEnable? Boolean.TRUE: Boolean.FALSE);
            TvingRowSupportFragment.setQualityType(mSettingsData.mTvingSettings.mQualityType);
            OksusuRowSupportFragment.setEnable(mSettingsData.mOksusuSettings.mEnable? Boolean.TRUE: Boolean.FALSE);
            OksusuRowSupportFragment.setQualityType(mSettingsData.mOksusuSettings.mQualityType);

        } else {
            normalizeServiceSettings();
            PooqRowSupportFragment.setEnable(mSettingsData.mPooqSettings.mEnable? Boolean.TRUE: Boolean.FALSE);
            PooqRowSupportFragment.setQualityType(mSettingsData.mPooqSettings.mQualityType);

            TvingRowSupportFragment.setEnable(mSettingsData.mTvingSettings.mEnable? Boolean.TRUE: Boolean.FALSE);
            TvingRowSupportFragment.setQualityType(mSettingsData.mTvingSettings.mQualityType);

            mSettingsData.mOksusuSettings.mQualityType = SettingsData.OksusuQualityType.FullHD;
            OksusuRowSupportFragment.setEnable(mSettingsData.mOksusuSettings.mEnable? Boolean.TRUE: Boolean.FALSE);
            OksusuRowSupportFragment.setQualityType(mSettingsData.mOksusuSettings.mQualityType);
        }

        setupUIElements();

        getMainFragmentRegistry().registerFragment(PageRow.class, new PageRowFragmentFactory());

        mCategoryRowAdapter = new ArrayObjectAdapter(new ListRowPresenter());
        setAdapter(mCategoryRowAdapter);

        createDefaultRows();

        setupEventListeners();

        mPicassoBackgroundManager = new PicassoBackgroundManager(getActivity());

        mChannelResultReceiver = new FetchChannelResultReceiver(mHandler);
        mChannelResultReceiver.setReceiver(this);

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        TimerTask task = new TimerTask() {
            @Override
            public void run() {

                String now =  new SimpleDateFormat("HH").format(new Date());

                if(now.compareTo(mUpdateTime) != 0) {

                    Fragment fragment = getMainFragment();

                    if (fragment instanceof AllTvBaseRowsSupportFragment) {

                        mUpdateTime = now;

                        if (shouldFetchPooqSection()) {
                            refreshServiceIntent(Utils.SiteType.Pooq);
                        }
                        if (shouldFetchTvingSection()) {
                            refreshServiceIntent(Utils.SiteType.Tving);
                        }
                        if (shouldFetchOksusuSection()) {
                            refreshServiceIntent(Utils.SiteType.Oksusu);
                        }
                    }

                } else {
                    Fragment fragment = getMainFragment();

                    if (fragment instanceof AllTvBaseRowsSupportFragment) {
                        ((AllTvBaseRowsSupportFragment) fragment).refreshRows();
                    }
                }
            }
        };

        mUpdateTime = new SimpleDateFormat("HH").format(new Date());

        mTimer = new Timer();
        mTimer.schedule(task, 10 * 60 * 1000, 10 * 60 * 1000);

    }

    public void startServiceIntent(Utils.SiteType inSiteType) {

        mSpinnerFragment[inSiteType.ordinal()] = new SpinnerFragment();
        getFragmentManager().beginTransaction().add(R.id.main_browse_fragment, mSpinnerFragment[inSiteType.ordinal()]).commit();

        // Start Service Intent
        Intent serviceIntent = new Intent(getActivity(), FetchChannelService.class);

        String mySettingsJson = mGson.toJson(mSettingsData);

        serviceIntent.putExtra(getStringById(R.string.FETCHCHANNELRESULTRECEIVER_STR), mChannelResultReceiver);
        serviceIntent.putExtra(getStringById(R.string.SETTINGSDATA_STR), mySettingsJson);
        serviceIntent.putExtra(getStringById(R.string.SITETYPE_STR), inSiteType);
        serviceIntent.putExtra(getStringById(R.string.AUTHKEY_STR), "");
        serviceIntent.putExtra(getStringById(R.string.FETCHMODE_STR), "create");

        getActivity().startService(serviceIntent);
    }

    public void refreshServiceIntent(Utils.SiteType inSiteType) {

        if(PlayerActivity.active) {
            mSpinnerFragment[inSiteType.ordinal()] = null;
        } else {
            mSpinnerFragment[inSiteType.ordinal()] = new SpinnerFragment();
            getFragmentManager().beginTransaction().add(R.id.main_browse_fragment, mSpinnerFragment[inSiteType.ordinal()]).commit();
        }

        // Start Service Intent
        Intent serviceIntent = new Intent(getActivity(), FetchChannelService.class);

        String mySettingsJson = mGson.toJson(mSettingsData);
        String authkey = AllTvBaseRowsSupportFragment.getAuthKey(inSiteType);

        serviceIntent.putExtra(getStringById(R.string.FETCHCHANNELRESULTRECEIVER_STR), mChannelResultReceiver);
        serviceIntent.putExtra(getStringById(R.string.SETTINGSDATA_STR), mySettingsJson);
        serviceIntent.putExtra(getStringById(R.string.SITETYPE_STR), inSiteType);
        serviceIntent.putExtra(getStringById(R.string.AUTHKEY_STR), authkey);
        serviceIntent.putExtra(getStringById(R.string.FETCHMODE_STR), "refresh");
        serviceIntent.putParcelableArrayListExtra(getStringById(R.string.CHANNELS_STR),
                AllTvBaseRowsSupportFragment.mChannels.get(inSiteType));
        serviceIntent.putParcelableArrayListExtra(getStringById(R.string.CATEGORY_STR),
                AllTvBaseRowsSupportFragment.mCategory.get(inSiteType));

        getActivity().startService(serviceIntent);
    }

    public class PageRowFragmentFactory extends BrowseSupportFragment.FragmentFactory<Fragment> {

        @Override
        public Fragment createFragment(Object rowObj) {

            Row row = (Row) rowObj;

            if(row.getHeaderItem().getId() == Utils.Header.Favorite.ordinal()) {
                return new FavoriteRowSupportFragment();
            }  else if (row.getHeaderItem().getId() == Utils.Header.Pooq.ordinal()) {
                return new PooqRowSupportFragment();
            } else if (row.getHeaderItem().getId() == Utils.Header.Tving.ordinal()) {
                return new TvingRowSupportFragment();
            } else if (row.getHeaderItem().getId() == Utils.Header.Oksusu.ordinal()) {
                return new OksusuRowSupportFragment();
            }

            throw new IllegalArgumentException(String.format("Invalid row %s", rowObj));
        }
    }

    private void setupUIElements() {
        setTitle(getStringById(R.string.browse_title));

        setHeadersState(HEADERS_ENABLED);
        setHeadersTransitionOnBackEnabled(true);

        setBrandColor(ContextCompat.getColor(getContext(), R.color.fastlane_background));
        setSearchAffordanceColor(ContextCompat.getColor(getContext(), R.color.search_opaque));
    }

    public void createDefaultRows() {

        mCategoryRowAdapter.clear();

        //Pooq
        if(shouldShowPooqSection()) {
            HeaderItem pooqHeader = new HeaderItem(Utils.Header.Pooq.ordinal(),
                    getStringById(R.string.pooq));
            mCategoryRowAdapter.add(new PageRow(pooqHeader));
        }

        //Tving
        if(shouldShowTvingSection()) {
            HeaderItem tvingHeader = new HeaderItem(Utils.Header.Tving.ordinal(),
                    getStringById(R.string.tving));
            mCategoryRowAdapter.add(new PageRow(tvingHeader));
        }

        //Favorite
        HeaderItem favoriteHeader = new HeaderItem(Utils.Header.Favorite.ordinal(),
                getStringById(R.string.favorite));
        mCategoryRowAdapter.add(new PageRow(favoriteHeader));

        //Oksusu
        if(shouldShowOksusuSection()) {
            HeaderItem oksusuHeader = new HeaderItem(Utils.Header.Oksusu.ordinal(),
                    getStringById(R.string.oksusu));
            mCategoryRowAdapter.add(new PageRow(oksusuHeader));
        }

        // Etc
        HeaderItem gridHeader = new HeaderItem(Utils.Header.Etc.ordinal(),
                getStringById(R.string.etc));

        GridItemPresenter gridItemPresenter = new GridItemPresenter();
        ArrayObjectAdapter gridRowAdapter = new ArrayObjectAdapter(gridItemPresenter);

        gridRowAdapter.add(getStringById(R.string.preferences));
        gridRowAdapter.add(getStringById(R.string.opensource));
        gridRowAdapter.add(getStringById(R.string.donation));
        gridRowAdapter.add(getStringById(R.string.version_str) + " " + BuildConfig.VERSION_NAME);

        mCategoryRowAdapter.add(new ListRow(gridHeader, gridRowAdapter));
    }

    private void setupEventListeners() {

        setOnItemViewClickedListener(this);
        setOnItemViewSelectedListener(this);
    }

    @Override
    public void onItemClicked(Presenter.ViewHolder itemViewHolder, Object item,
                              RowPresenter.ViewHolder rowViewHolder, Row row) {

        if (item instanceof String) {
            if (((String) item).contains(getString(R.string.preferences))) {

                Intent intent = new Intent(getActivity(), SettingsActivity.class);
                intent.putExtra(getStringById(R.string.SETTINGSDATA_STR), mGson.toJson(mSettingsData));
                getActivity().startActivityForResult(intent, Utils.Code.SettingsRequestCode.ordinal());

            } else if (((String) item).contains(getString(R.string.opensource))) {
                showLicensesDialogFragment();
            } else if (((String) item).contains(getString(R.string.donation))) {
                showDonationDialogFragment();
            }
        }

    }

    @Override
    public void onItemSelected(Presenter.ViewHolder itemViewHolder, Object item,
                               RowPresenter.ViewHolder rowViewHolder, Row row) {

        if (item instanceof String) {
            if (mPicassoBackgroundManager != null) {
                mPicassoBackgroundManager.updateBackgroundWithDelay();
            }
        } else if (item instanceof ChannelData) {
            if (mPicassoBackgroundManager != null) {
                mPicassoBackgroundManager.updateBackgroundWithDelay(((ChannelData) item).getStillImageUrl());
            }
        }
    }

    // GridItemPresenter
    private class GridItemPresenter extends Presenter {

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent) {

            TextView view = new TextView(parent.getContext());

            view.setLayoutParams(new ViewGroup.LayoutParams(getResources().getInteger(R.integer.GRID_ITEM_WIDTH), getResources().getInteger(R.integer.GRID_ITEM_HEIGHT)));
            view.setFocusable(true);
            view.setFocusableInTouchMode(true);
            view.setBackgroundResource(R.drawable.grid_item_background);
            view.setTextColor(Color.WHITE);
            view.setGravity(Gravity.CENTER);
            view.setPadding(36, 24, 36, 24);
            view.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
            view.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            view.setMaxLines(2);
            view.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                @Override
                public void onFocusChange(View v, boolean hasFocus) {
                    v.setBackgroundResource(hasFocus ? R.drawable.grid_item_background_focused : R.drawable.grid_item_background);
                    v.animate()
                            .scaleX(hasFocus ? 1.05f : 1.0f)
                            .scaleY(hasFocus ? 1.05f : 1.0f)
                            .setDuration(140)
                            .start();
                }
            });

            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(ViewHolder viewHolder, Object item) {
            ((TextView) viewHolder.view).setText((String) item);
        }

        @Override
        public void onUnbindViewHolder(ViewHolder viewHolder) {

        }
    }

    @Override
    public void onReceiveResult(int resultCode, Bundle resultData) {

        Utils.SiteType siteType = (Utils.SiteType)resultData.get(getStringById(R.string.SITETYPE_STR));
        String fetchMode = (String)resultData.get(getStringById(R.string.FETCHMODE_STR));
        boolean refresh = fetchMode.equals("refresh");

        ArrayList<ChannelData> chList;

        if(!PlayerActivity.active && mSpinnerFragment[siteType.ordinal()] != null) {
            getFragmentManager().beginTransaction().remove(mSpinnerFragment[siteType.ordinal()]).commit();
            mSpinnerFragment[siteType.ordinal()] = null;
        }

        switch (Utils.Code.values()[resultCode]) {
            case ServiceIntent_OK:
                if (resultData != null) {
                    String authKey = resultData.getString(getStringById(R.string.AUTHKEY_STR), "");

                    if (!refresh) {
                        updateServiceStatus(siteType,
                                authKey != null && authKey.length() > 0
                                        ? getStringById(R.string.login_status_ok)
                                        : getStringById(R.string.login_status_list_ok));
                    }

                    switch (siteType) {

                        case Pooq:
                            chList = resultData.getParcelableArrayList(getStringById(R.string.CHANNELS_STR));
                            applyAuthKey(chList, authKey);

                            if (Hawk.contains(getStringById(R.string.POOQ_CHANNELS_STR))) {
                                String str = Hawk.get(getStringById(R.string.POOQ_CHANNELS_STR));
                                ArrayList<String> favorites = mGson.fromJson(str,
                                        new TypeToken<ArrayList<String>>() {}.getType());
                                for(ChannelData chData : chList) {
                                    for (String val : favorites)
                                        if (val.contains(chData.getId())) chData.setFavorite(1);
                                }
                            }

                            if(!refresh) {
                                PooqRowSupportFragment.setChannelList(chList);
                                PooqRowSupportFragment.setCategoryList(resultData.getParcelableArrayList(getStringById(R.string.CATEGORY_STR)));
                                PooqRowSupportFragment.setAuthKey(authKey);
                            } else {
                                PooqRowSupportFragment.updateEPG(chList);
                            }
                            break;

                        case Tving:
                            chList = resultData.getParcelableArrayList(getStringById(R.string.CHANNELS_STR));
                            applyAuthKey(chList, authKey);
                            if (Hawk.contains(getStringById(R.string.TVING_CHANNELS_STR))) {
                                String str = Hawk.get(getStringById(R.string.TVING_CHANNELS_STR));
                                ArrayList<String> favorites = mGson.fromJson(str,
                                        new TypeToken<ArrayList<String>>() {}.getType());
                                for(ChannelData chData : chList) {
                                    for (String val : favorites)
                                        if (val.contains(chData.getId())) chData.setFavorite(1);
                                }
                            }

                            if(!refresh) {
                                TvingRowSupportFragment.setChannelList(chList);
                                TvingRowSupportFragment.setCategoryList(resultData.getParcelableArrayList(getStringById(R.string.CATEGORY_STR)));
                                TvingRowSupportFragment.setAuthKey(authKey);
                            } else {
                                TvingRowSupportFragment.updateEPG(chList);
                            }
                            break;

                        case Oksusu:
                            chList = resultData.getParcelableArrayList(getStringById(R.string.CHANNELS_STR));
                            applyAuthKey(chList, authKey);
                            if (Hawk.contains(getStringById(R.string.OKSUSU_CHANNELS_STR))) {
                                String str = Hawk.get(getStringById(R.string.OKSUSU_CHANNELS_STR));
                                ArrayList<String> favorites = mGson.fromJson(str,
                                        new TypeToken<ArrayList<String>>() {}.getType());
                                for(ChannelData chData : chList) {
                                    for (String val : favorites)
                                        if (val.contains(chData.getId())) chData.setFavorite(1);
                                }
                            }

                            if(!refresh) {
                                OksusuRowSupportFragment.setChannelList(chList);
                                OksusuRowSupportFragment.setCategoryList(resultData.getParcelableArrayList(getStringById(R.string.CATEGORY_STR)));
                                OksusuRowSupportFragment.setAuthKey(authKey);
                            } else {
                                OksusuRowSupportFragment.updateEPG(chList);
                            }
                            break;
                    }

                    Fragment fragment = getMainFragment();

                    if(siteType == Utils.SiteType.Pooq && fragment instanceof PooqRowSupportFragment) {
                        if(PlayerActivity.active)
                            ((PooqRowSupportFragment) fragment).sendChannelData();
                        else if(refresh)
                            ((PooqRowSupportFragment) fragment).refreshRows();
                        else
                            ((PooqRowSupportFragment) fragment).createRows();
                    }  else if(siteType == Utils.SiteType.Tving && fragment instanceof TvingRowSupportFragment) {
                        if(PlayerActivity.active)
                            ((TvingRowSupportFragment) fragment).sendChannelData();
                        else if(refresh)
                            ((TvingRowSupportFragment) fragment).refreshRows();
                        else
                            ((TvingRowSupportFragment) fragment).createRows();
                    } else if(siteType == Utils.SiteType.Oksusu && fragment instanceof OksusuRowSupportFragment) {
                        if(PlayerActivity.active)
                            ((OksusuRowSupportFragment) fragment).sendChannelData();
                        else if(refresh)
                            ((OksusuRowSupportFragment) fragment).refreshRows();
                        else
                            ((OksusuRowSupportFragment) fragment).createRows();
                    }

                    if(fragment instanceof FavoriteRowSupportFragment) {

                        if(siteType == Utils.SiteType.Pooq) {
                            if(mSettingsData.mTvingSettings.mEnable || mSettingsData.mOksusuSettings.mEnable) {
                                break;
                            }
                        } else if(siteType == Utils.SiteType.Tving) {
                            if(mSettingsData.mOksusuSettings.mEnable) {
                                break;
                            }
                        }

                        if(PlayerActivity.active)
                            ((FavoriteRowSupportFragment) fragment).sendChannelData();
                        else if(refresh)
                            ((FavoriteRowSupportFragment) fragment).refreshRows();
                        else
                            ((FavoriteRowSupportFragment) fragment).createRows();
                    }

                }
                break;

            case ServiceIntent_Fail:
                if (!refresh) {
                    updateServiceStatus(siteType, getStringById(R.string.login_status_fail));
                }

                switch (siteType) {
                    case Pooq:
                        Utils.showToast(getContext(), R.string.pooq_login_fail);
                        break;
                    case Tving:
                        Utils.showToast(getContext(), R.string.tving_login_fail);
                        break;
                    case Oksusu:
                        Utils.showToast(getContext(), R.string.oksusu_login_fail);
                        break;
                }
                break;
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        ArrayList<ChannelData> chList;
        ArrayList<String> favorites = new ArrayList<String>();
        Fragment fragment;

        switch (Utils.Code.values()[requestCode]) {
            case SettingsRequestCode:
                if (resultCode == 0)
                    return;

                String settingsStr = data.getStringExtra(getStringById(R.string.SETTINGSDATA_STR));
                mSettingsData = mGson.fromJson(settingsStr, SettingsData.class);

                if (resultCode == Utils.Code.PooqSave.ordinal()) {
                    PooqRowSupportFragment.setEnable(mSettingsData.mPooqSettings.mEnable ? Boolean.TRUE : Boolean.FALSE);
                    PooqRowSupportFragment.setQualityType(mSettingsData.mPooqSettings.mQualityType);
                    AllTvBaseRowsSupportFragment.updateChannelQuality(
                            Utils.SiteType.Pooq, mSettingsData.mPooqSettings.mQualityType.ordinal());

                    if (shouldFetchPooqSection()) {
                        startServiceIntent(Utils.SiteType.Pooq);
                    } else {
                        clearServiceSection(Utils.SiteType.Pooq);
                    }
                } else if (resultCode == Utils.Code.TvingSave.ordinal()) {
                    TvingRowSupportFragment.setEnable(mSettingsData.mTvingSettings.mEnable ? Boolean.TRUE : Boolean.FALSE);
                    TvingRowSupportFragment.setQualityType(mSettingsData.mTvingSettings.mQualityType);
                    AllTvBaseRowsSupportFragment.updateChannelQuality(
                            Utils.SiteType.Tving, mSettingsData.mTvingSettings.mQualityType.ordinal());

                    if (shouldFetchTvingSection()) {
                        startServiceIntent(Utils.SiteType.Tving);
                    } else {
                        clearServiceSection(Utils.SiteType.Tving);
                    }
                } else if (resultCode == Utils.Code.OksusuSave.ordinal()) {
                    OksusuRowSupportFragment.setEnable(mSettingsData.mOksusuSettings.mEnable ? Boolean.TRUE : Boolean.FALSE);
                    OksusuRowSupportFragment.setQualityType(mSettingsData.mOksusuSettings.mQualityType);
                    if (mSettingsData.mOksusuSettings.mEnable) {
                        startServiceIntent(Utils.SiteType.Oksusu);
                    }
                }

                if (!Hawk.put(getStringById(R.string.SETTINGS_STR), mGson.toJson(mSettingsData))) {
                    Utils.showToast(getContext(), R.string.settingssave_error);
                    return;
                }

                createDefaultRows();

                break;

            case FavoritePlay:

                boolean updated = false;

                if (resultCode == -1) {
                    chList = data.getParcelableArrayListExtra(getStringById(R.string.CHANNELS_STR));

                    favorites.clear();
                    for (int i = 0; i < chList.size(); i++) {
                        ChannelData chData = chList.get(i);
                        if (chData.getSiteType() == Utils.SiteType.Pooq.ordinal() && chData.getFavorite() > 0)
                            favorites.add(chData.getId());
                    }

                    if (PooqRowSupportFragment.updateFavoriteList(favorites)) {
                        updated = true;
                        if (!Hawk.put(getStringById(R.string.POOQ_CHANNELS_STR), mGson.toJson(favorites))) {
                            return;
                        }
                    }

                    favorites.clear();
                    for (int i = 0; i < chList.size(); i++) {
                        ChannelData chData = chList.get(i);
                        if (chData.getSiteType() == Utils.SiteType.Tving.ordinal() && chData.getFavorite() > 0)
                            favorites.add(chData.getId());
                    }

                    if (TvingRowSupportFragment.updateFavoriteList(favorites)) {
                        updated = true;
                        if (!Hawk.put(getStringById(R.string.TVING_CHANNELS_STR), mGson.toJson(favorites))) {
                            return;
                        }
                    }

                    favorites.clear();
                    for (int i = 0; i < chList.size(); i++) {
                        ChannelData chData = chList.get(i);
                        if (chData.getSiteType() == Utils.SiteType.Oksusu.ordinal() && chData.getFavorite() > 0)
                            favorites.add(chData.getId());
                    }

                    if (OksusuRowSupportFragment.updateFavoriteList(favorites)) {
                        updated = true;
                        if (!Hawk.put(getStringById(R.string.OKSUSU_CHANNELS_STR), mGson.toJson(favorites))) {
                            return;
                        }
                    }
                }

                fragment = getMainFragment();
                if (fragment instanceof AllTvBaseRowsSupportFragment) {
                    if( updated )
                        ((AllTvBaseRowsSupportFragment) fragment).createRows();
                    else
                        ((AllTvBaseRowsSupportFragment) fragment).refreshRows();
                }

                break;

            case PooqPlay:
                if (resultCode == -1) {
                    chList = data.getParcelableArrayListExtra(getStringById(R.string.CHANNELS_STR));

                    favorites.clear();
                    for (int i = 0; i < chList.size(); i++) {
                        ChannelData chData = chList.get(i);
                        if (chData.getFavorite() > 0) favorites.add(chData.getId());
                    }

                    if (PooqRowSupportFragment.updateFavoriteList(favorites)) {
                        if (!Hawk.put(getStringById(R.string.POOQ_CHANNELS_STR), mGson.toJson(favorites))) {
                            return;
                        }
                    }
                }

                fragment = getMainFragment();

                if (fragment instanceof AllTvBaseRowsSupportFragment)
                    ((AllTvBaseRowsSupportFragment) fragment).refreshRows();

                break;

            case TvingPlay:
                if(resultCode == -1) {
                    chList = data.getParcelableArrayListExtra(getStringById(R.string.CHANNELS_STR));

                    favorites.clear();
                    for (int i = 0; i < chList.size(); i++) {
                        ChannelData chData = chList.get(i);
                        if (chData.getFavorite() > 0) favorites.add(chData.getId());
                    }

                    if (TvingRowSupportFragment.updateFavoriteList(favorites)) {
                        if (!Hawk.put(getStringById(R.string.TVING_CHANNELS_STR), mGson.toJson(favorites))) {
                            return;
                        }
                    }
                }

                fragment = getMainFragment();
                if(fragment instanceof AllTvBaseRowsSupportFragment)
                    ((AllTvBaseRowsSupportFragment) fragment).refreshRows();

                break;

            case OksusuPlay:
                if(resultCode == -1) {
                    chList = data.getParcelableArrayListExtra(getStringById(R.string.CHANNELS_STR));

                    favorites.clear();
                    for (int i = 0; i < chList.size(); i++) {
                        ChannelData chData = chList.get(i);
                        if (chData.getFavorite() > 0) favorites.add(chData.getId());
                    }

                    if (OksusuRowSupportFragment.updateFavoriteList(favorites)) {
                        if (!Hawk.put(getStringById(R.string.OKSUSU_CHANNELS_STR), mGson.toJson(favorites))) {
                            return;
                        }
                    }
                }

                fragment = getMainFragment();
                if(fragment instanceof AllTvBaseRowsSupportFragment)
                    ((AllTvBaseRowsSupportFragment) fragment).refreshRows();

                break;
        }
    }

    private void showLicensesDialogFragment() {

        LicensesDialogFragment dialog = LicensesDialogFragment.newInstance();
        dialog.show(getActivity().getSupportFragmentManager(), getStringById(R.string.LICENSESDIALOG_STR));

    }

    private void showDonationDialogFragment() {

        DonationDialogFragment dialog = DonationDialogFragment.newInstance();
        dialog.show(getActivity().getSupportFragmentManager(), getStringById(R.string.DONATIONDIALOG_STR));

    }
}
