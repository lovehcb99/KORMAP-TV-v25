/*
 * MIT License
 *
 * Copyright (c) 2019 PYTHONKOR

 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:

 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.

 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

package com.ksi.alltv;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Point;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import androidx.fragment.app.FragmentActivity;

import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.exoplayer2.ExoPlaybackException;
import com.google.android.exoplayer2.ExoPlayerFactory;
import com.google.android.exoplayer2.Player;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.source.TrackGroupArray;
import com.google.android.exoplayer2.source.hls.HlsMediaSource;
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector;
import com.google.android.exoplayer2.trackselection.TrackSelectionArray;
import com.google.android.exoplayer2.ui.PlayerView;
import com.google.android.exoplayer2.upstream.DataSource;
import com.google.android.exoplayer2.upstream.DefaultDataSourceFactory;
import com.google.android.exoplayer2.upstream.DefaultHttpDataSourceFactory;
import com.google.android.exoplayer2.util.Util;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.UUID;


public class PlayerActivity extends FragmentActivity implements Player.EventListener, Target {

    private static final String TAG = PlayerActivity.class.getSimpleName();

    static boolean active = false;

    private Activity mContext;
    private PlayerView mPlayerView;
    private SimpleExoPlayer mPlayer;

    private ArrayList<ChannelData> mChannels;
    private int mCurrentChannel;
    private int mChannelIndex;
    private int mEPGIndex;

    private SlidingPanel mSlidingPanel;
    private ProgressBar mProgressBar;

    private Point mWindowSize;
    private boolean isLongPressed = false;
    private boolean isSaveNeeded = false;
    private int mPlayingChannel = -1;
    private String mTvingRequestedQualityTag = "";
    private String mTvingResolvedQualityTag = "";
    private boolean mTvingQualityRetryInProgress = false;

    private String getStringById(int resourceId) {
        return this.getResources().getString(resourceId);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_videoplayer);

        mContext = this;

        mPlayerView = (PlayerView)findViewById(R.id.video_view);
        mProgressBar = (ProgressBar)findViewById(R.id.progressBar);

        mProgressBar.setVisibility(View.VISIBLE);

        mSlidingPanel = new SlidingPanel(this);

        mWindowSize = Utils.getDisplaySize(this);

        isLongPressed = false;
        isSaveNeeded = false;

        createPlayer();

        mPlayerView.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {

                float left, right, top, bottom, mid;

                left  = (float) (mWindowSize.x * 0.1);
                right = (float) (mWindowSize.x * 0.9);
                mid   = (float) (mWindowSize.x * 0.5);
                top = left;
                bottom = (float)(mWindowSize.y - top);

                if(motionEvent.getX() < left) {
                    if (motionEvent.getY() < top) {
                        Intent intent = new Intent();
                        intent.putParcelableArrayListExtra(getStringById(R.string.CHANNELS_STR), mChannels);
                        if( isSaveNeeded )
                            setResult(RESULT_OK, intent);
                        else
                            setResult(RESULT_CANCELED, intent);
                        finishAfterTransition();
                    } else {

                        if (mSlidingPanel.isPanelShow()) {
                            if (mEPGIndex >= 0) {
                                if (mEPGIndex > 0) mEPGIndex -= 1;
                                displayProgramInfo(3000);
                            }
                        } else {
                            if (mCurrentChannel > 0) {
                                mCurrentChannel -= 1;
                                mSlidingPanel.hideSlidingPanel();
                                mProgressBar.setVisibility(View.VISIBLE);
                                new FetchVideoUrlTask().execute(mCurrentChannel);
                            } else {
                                Toast.makeText(mContext, getStringById(R.string.first_channel),
                                        Toast.LENGTH_SHORT).show();
                            }
                        }
                    }

                } else if(motionEvent.getX() > right) {

                    if (motionEvent.getY() < top) {

                        if(!mSlidingPanel.isPanelShow()) {
                            showProgramInfo(3000);
                        }

                        if (mCurrentChannel != mChannelIndex) {
                            return false;
                        }

                        ChannelData chData = mChannels.get(mCurrentChannel);
                        isSaveNeeded = true;
                        if (chData.getFavorite() > 0) {
                            chData.setFavorite(0);
                            mSlidingPanel.hideFavorite();
                            Toast.makeText(mContext, getStringById(R.string.favorite_disable),
                                    Toast.LENGTH_SHORT).show();
                        } else {
                            chData.setFavorite(1);
                            mSlidingPanel.showFavorite();
                            Toast.makeText(mContext, getStringById(R.string.favorite_enable),
                                    Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        if (mSlidingPanel.isPanelShow()) {

                            if (mEPGIndex >= 0) {
                                int size = mChannels.get(mChannelIndex).getEPG().size() - 1;
                                if (mEPGIndex < size) mEPGIndex += 1;
                                displayProgramInfo(3000);
                            }

                        } else {

                            if (mCurrentChannel < mChannels.size() - 1) {
                                mCurrentChannel += 1;
                                mSlidingPanel.hideSlidingPanel();
                                mProgressBar.setVisibility(View.VISIBLE);
                                new FetchVideoUrlTask().execute(mCurrentChannel);
                            } else {
                                Toast.makeText(mContext, getStringById(R.string.last_channel),
                                        Toast.LENGTH_SHORT).show();
                            }

                        }
                    }

                } else if(motionEvent.getX() > (mid-left) && motionEvent.getX() < (mid+left) &&
                         (motionEvent.getY() < top || motionEvent.getY() > bottom)) {

                    if(mSlidingPanel.isPanelShow()) {
                        if(motionEvent.getY() < top) {

                            if(mChannelIndex < mChannels.size()-1)
                                mChannelIndex += 1;
                            else
                                mChannelIndex = 0;

                            changeChannelInfo(3000);

                        } else if( motionEvent.getY() > bottom) {

                            if(mChannelIndex > 0)
                                mChannelIndex -= 1;
                            else
                                mChannelIndex = mChannels.size()-1;

                            changeChannelInfo(3000);
                        }
                    }

                } else {
                    if(mSlidingPanel.isPanelShow()) {

                        mSlidingPanel.hideSlidingPanel();

                        if(mCurrentChannel != mChannelIndex) {
                            mCurrentChannel = mChannelIndex;
                            mProgressBar.setVisibility(View.VISIBLE);
                            new FetchVideoUrlTask().execute(mCurrentChannel);
                        }

                    }
                    else {
                        showProgramInfo(3000);
                    }
                }
                return false;
            }
        });

        mSlidingPanel.setInfoText("");

        mChannels = getIntent().getParcelableArrayListExtra(getStringById(R.string.CHANNELS_STR));
        mCurrentChannel = getIntent().getIntExtra(getStringById(R.string.CURRENTCHANNEL_STR), 0);

        new FetchVideoUrlTask().execute(mCurrentChannel);

    }

    @Override
    protected void onNewIntent(Intent intent) {
        ArrayList<ChannelData> channelData = intent.getParcelableArrayListExtra(getStringById(R.string.CHANNELS_STR));

        mChannels.clear();
        mChannels = channelData;
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {

        if (keyCode == KeyEvent.KEYCODE_DPAD_CENTER) {

            if (mSlidingPanel.isPanelShow()) {
                if( isLongPressed ) {
                    isLongPressed = false;
                } else {
                    mSlidingPanel.hideSlidingPanel();

                    if(mCurrentChannel != mChannelIndex) {
                        mCurrentChannel = mChannelIndex;
                        mProgressBar.setVisibility(View.VISIBLE);
                        new FetchVideoUrlTask().execute(mCurrentChannel);
                    }
                }
            } else {
                showProgramInfo(3000);
            }
        }

        return super.onKeyDown(keyCode, event);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {

        if (keyCode == KeyEvent.KEYCODE_DPAD_CENTER) {

            if( event.isLongPress() ) {

                isLongPressed = true;

                if(!mSlidingPanel.isPanelShow()) {
                    showProgramInfo(3000);
                }

                if(mCurrentChannel != mChannelIndex) {
                    return false;
                }

                isSaveNeeded = true;
                ChannelData chData = mChannels.get(mCurrentChannel);

                if (chData.getFavorite() > 0) {
                    chData.setFavorite(0);
                    mSlidingPanel.hideFavorite();
                    Toast.makeText(mContext, getStringById(R.string.favorite_disable),
                            Toast.LENGTH_SHORT).show();

                } else {
                    chData.setFavorite(1);
                    mSlidingPanel.showFavorite();
                    Toast.makeText(mContext, getStringById(R.string.favorite_enable),
                            Toast.LENGTH_SHORT).show();
                }

            } else {
                mSlidingPanel.closeDelayed(3000);
            }

        } else if(keyCode == KeyEvent.KEYCODE_BACK) {
            if(mSlidingPanel.isPanelShow()) {
                mSlidingPanel.hideSlidingPanel();
                return false;
            } else {

                Intent intent = new Intent();
                intent.putParcelableArrayListExtra(getStringById(R.string.CHANNELS_STR), mChannels);

                if( isSaveNeeded )
                    setResult(RESULT_OK, intent);
                else
                    setResult(RESULT_CANCELED, intent);

                finishAfterTransition();
            }

        } else if(keyCode == KeyEvent.KEYCODE_DPAD_UP ||
                  keyCode == KeyEvent.KEYCODE_CHANNEL_UP) {

            if(mSlidingPanel.isPanelShow()) {
                if(mChannelIndex < mChannels.size()-1)
                    mChannelIndex += 1;
                else
                    mChannelIndex = 0;

                changeChannelInfo(3000);

            } else {
                if(mCurrentChannel < mChannels.size()-1) {
                    mCurrentChannel += 1;
                    mSlidingPanel.hideSlidingPanel();
                    mProgressBar.setVisibility(View.VISIBLE);
                    new FetchVideoUrlTask().execute(mCurrentChannel);
                } else {
                    Toast.makeText(mContext, getStringById(R.string.last_channel),
                            Toast.LENGTH_SHORT).show();
                }
            }

        } else if(keyCode == KeyEvent.KEYCODE_DPAD_DOWN ||
                  keyCode == KeyEvent.KEYCODE_CHANNEL_DOWN) {

            if(mSlidingPanel.isPanelShow()) {
                if(mChannelIndex > 0)
                    mChannelIndex -= 1;
                else
                    mChannelIndex = mChannels.size()-1;

                changeChannelInfo(3000);

            } else {
                if(mCurrentChannel > 0) {
                    mCurrentChannel -= 1;
                    mSlidingPanel.hideSlidingPanel();
                    mProgressBar.setVisibility(View.VISIBLE);
                    new FetchVideoUrlTask().execute(mCurrentChannel);
                } else {
                    Toast.makeText(mContext, getStringById(R.string.first_channel),
                            Toast.LENGTH_SHORT).show();
                }
            }

        } else if(keyCode == KeyEvent.KEYCODE_DPAD_LEFT) {

            if(mSlidingPanel.isPanelShow()) {
                if(mEPGIndex >= 0) {
                    if (mEPGIndex > 0) mEPGIndex -= 1;
                }
                displayProgramInfo(3000);
            }

        } else if(keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) {

            if(mSlidingPanel.isPanelShow()) {
                if(mEPGIndex >= 0) {
                    int size = mChannels.get(mChannelIndex).getEPG().size()-1;
                    if (mEPGIndex < size) mEPGIndex += 1;
                }
                displayProgramInfo(3000);
            }

        }

        return super.onKeyDown(keyCode, event);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

        mSlidingPanel.hideSlidingPanel();
        releasePlayer();
    }

    private void showProgramInfo(int msec) {

        mChannelIndex = mCurrentChannel;

        ChannelData chData = mChannels.get(mChannelIndex);
        ArrayList<EPGData> epgData = chData.getEPG();

        mEPGIndex = -1;

        for(int i=0; i<epgData.size(); i++) {
            Date now = new Date();
            if(now.compareTo(epgData.get(i).getEndTime()) < 0) {
                mEPGIndex = i;
                break;
            }
        }

        displayProgramInfo(0);

        if(!mSlidingPanel.isPanelShow())
            mSlidingPanel.showSlidingPanel(msec);

    }

    private void changeChannelInfo(int msec) {

        ChannelData chData = mChannels.get(mChannelIndex);
        ArrayList<EPGData> epgData = chData.getEPG();

        mEPGIndex = -1;

        for(int i=0; i<epgData.size(); i++) {
            Date now = new Date();
            if(now.compareTo(epgData.get(i).getEndTime()) < 0) {
                mEPGIndex = i;
                break;
            }
        }

        displayProgramInfo(msec);
    }

    private void displayProgramInfo(int msec) {

        ChannelData chData = mChannels.get(mChannelIndex);
        ArrayList<EPGData> epgData = chData.getEPG();

        String title = chData.getTitle();

        if(mEPGIndex >= 0) {
            String name = epgData.get(mEPGIndex).getProgramName();
            Date stime = epgData.get(mEPGIndex).getStartTime();
            Date etime = epgData.get(mEPGIndex).getEndTime();

            String stimeStr = new SimpleDateFormat("HH:mm").format(stime);
            String etimeStr = new SimpleDateFormat("HH:mm").format(etime);

            mSlidingPanel.setInfoText(stimeStr + " ~ " + etimeStr + "\n" + title + " - " + name + "\n");
        } else {
            mSlidingPanel.setInfoText(title);
        }

        String currentTime = new SimpleDateFormat("HH:mm").format(new Date());
        mSlidingPanel.setTimeText(currentTime);

        if(chData.getFavorite() > 0) {
            mSlidingPanel.showFavorite();
        } else {
            mSlidingPanel.hideFavorite();
        }

        if(msec > 0)
            mSlidingPanel.closeDelayed(msec);

    }

    private void createPlayer() {

        if (mPlayer != null) {
            releasePlayer();
        }

        mPlayer = ExoPlayerFactory.newSimpleInstance(getApplicationContext(), new DefaultTrackSelector());

        mPlayerView.setPlayer(mPlayer);
        mPlayerView.setUseController(false);

        mPlayer.setPlayWhenReady(true);
        mPlayer.addListener(this);

        mPlayer.setVolume(1.0f);

        mSlidingPanel.setInfoText("");

    }

    private void openPlayer(String videoUrl) {

        ChannelData chData = mChannels.get(mCurrentChannel);

        if ( chData.isAudioChannel() ) {
            Picasso.get().load(chData.getStillImageUrl()).into(this);
        }

        if(videoUrl == null) return;

        Uri uriLive = Uri.parse(videoUrl);

        DataSource.Factory dataSourceFactory = new DefaultDataSourceFactory(this,
                getStringById(R.string.USERAGENT));
        HlsMediaSource mediaSourceLive = new HlsMediaSource.Factory(dataSourceFactory)
                .setAllowChunklessPreparation(true)
                .createMediaSource(uriLive);

        mPlayer.prepare(mediaSourceLive);

    }

    private void openPlayer(String videoUrl, String videoCookie) {

        ChannelData chData = mChannels.get(mCurrentChannel);

        if ( chData.isAudioChannel() ) {
            Picasso.get().load(chData.getStillImageUrl()).into(this);
        }

        if(videoUrl == null) return;

        Uri uriLive = Uri.parse(videoUrl);

        DefaultHttpDataSourceFactory httpSourceFactory = new DefaultHttpDataSourceFactory(
                getStringById(R.string.USERAGENT), null);

        if( videoCookie != null && !videoCookie.equals("") ) {
            httpSourceFactory.getDefaultRequestProperties().set("Cookie", videoCookie);
        }

        DataSource.Factory dataSourceFactory = new DefaultDataSourceFactory(this,
                null, httpSourceFactory);

        HlsMediaSource mediaSourceLive = new HlsMediaSource.Factory(dataSourceFactory)
                .setAllowChunklessPreparation(true)
                .createMediaSource(uriLive);

        mPlayer.prepare(mediaSourceLive);

    }

    private void releasePlayer() {

        if (mPlayer != null) {
            mPlayer.stop(true);
            mPlayer.release();
            mPlayer = null;
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        if (Util.SDK_INT <= 23) {
            releasePlayer();
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        active = true;
    }

    @Override
    public void onStop() {
        super.onStop();

        if (Util.SDK_INT > 23) {
            releasePlayer();
        }

        active = false;
        finish();
    }

    @Override
    public void onTracksChanged(TrackGroupArray trackGroups, TrackSelectionArray trackSelections) {

    }

    @Override
    public void onLoadingChanged(boolean isLoading) {

        if( isLoading )
            showProgramInfo(1000);

    }

    @Override
    public void onRepeatModeChanged(int repeatMode) {

    }

    @Override
    public void onShuffleModeEnabledChanged(boolean shuffleModeEnabled) {

    }

    @Override
    public void onPlayerError(ExoPlaybackException error) {
        Log.e(TAG, "Player error", error);

        if (tryRecoverTvingPlayback(error)) {
            return;
        }

        Utils.showToast(mContext, R.string.geturl_error);
    }

    @Override
    public void onPositionDiscontinuity(int reason) {

    }

    @Override
    public void onSeekProcessed() {

    }

    @Override
    public void onBitmapLoaded(Bitmap bitmap, Picasso.LoadedFrom from) {
        Drawable d = new BitmapDrawable(getResources(), bitmap);
        mPlayerView.setDefaultArtwork(d);
    }

    @Override
    public void onBitmapFailed(Exception e, Drawable errorDrawable) {

    }

    @Override
    public void onPrepareLoad(Drawable placeHolderDrawable) {

    }

    private class FetchVideoUrlTask extends AsyncTask<Integer, Integer, Integer> {

        private final String requestedQualityOverride;
        private final String qualityFallbackSourceTag;
        private String videoUrl = "";
        private String videoCookie = "";
        private String videoErrorMessage = "";
        private String videoInfoMessage = "";
        private int requestedChannelIndex = -1;
        private int previousChannelIndex = -1;
        private String resolvedQualityTag = "";
        private String requestedQualityTag = "";

        FetchVideoUrlTask() {
            this("", "");
        }

        FetchVideoUrlTask(String requestedQualityOverride, String qualityFallbackSourceTag) {
            this.requestedQualityOverride = requestedQualityOverride == null ? "" : requestedQualityOverride;
            this.qualityFallbackSourceTag = qualityFallbackSourceTag == null ? "" : qualityFallbackSourceTag;
        }

        protected Integer doInBackground(Integer... channelIndex) {

            ArrayList<ChannelData> chList = mChannels;
            int arrIndex = channelIndex[0];
            requestedChannelIndex = arrIndex;
            previousChannelIndex = mPlayingChannel;
            videoErrorMessage = "";
            videoInfoMessage = "";
            resolvedQualityTag = "";
            requestedQualityTag = "";

            if(arrIndex < 0)
                return Utils.Code.NoVideoUrl_err.ordinal();

            ChannelData chData = chList.get(arrIndex);

            if(chData.getSiteType() == Utils.SiteType.Oksusu.ordinal()) {
                return OksusuFetchVideoUrl(chData);
            } else if(chData.getSiteType() == Utils.SiteType.Pooq.ordinal()) {
                return PooqFetchVideoUrl(chData);
            } else if(chData.getSiteType() == Utils.SiteType.Tving.ordinal()) {
                return TvingFetchVideoUrl(chData);
            }

            return Utils.Code.NoVideoUrl_err.ordinal();
        }

        protected void onProgressUpdate(Integer... progress) {
            super.onProgressUpdate(progress);
        }

        protected void onPostExecute(Integer result) {

            mProgressBar.setVisibility(View.GONE);

            switch (Utils.Code.values()[result]) {
                case NoAuthKey_err:
                    Utils.showToast(mContext, R.string.login_error_video);
                    setResult(RESULT_CANCELED);
                    finishAfterTransition();
                    break;
                case NoVideoUrl_err:
                    mTvingQualityRetryInProgress = false;
                    if(videoErrorMessage != null && videoErrorMessage.length() > 0) {
                        Utils.showToast(mContext, videoErrorMessage);
                    } else {
                        Utils.showToast(mContext, R.string.geturl_error);
                    }

                    if (!restorePreviousChannel()) {
                        setResult(RESULT_CANCELED);
                        finishAfterTransition();
                    }
                    break;
                case FetchVideoUrlTask_OK:
                    mPlayingChannel = requestedChannelIndex;
                    mTvingQualityRetryInProgress = false;
                    if (mChannels.get(requestedChannelIndex).getSiteType() == Utils.SiteType.Tving.ordinal()) {
                        mTvingRequestedQualityTag = requestedQualityTag;
                        mTvingResolvedQualityTag = resolvedQualityTag;
                    } else {
                        mTvingRequestedQualityTag = "";
                        mTvingResolvedQualityTag = "";
                    }
                    if(videoInfoMessage != null && videoInfoMessage.length() > 0) {
                        Utils.showToast(mContext, videoInfoMessage);
                    }
                    if(videoCookie == null || videoCookie.equals(""))
                        openPlayer(videoUrl);
                    else
                        openPlayer(videoUrl, videoCookie);
                    break;
            }
        }

        private boolean restorePreviousChannel() {

            if (previousChannelIndex < 0 ||
                    previousChannelIndex >= mChannels.size()) {
                return false;
            }

            if (previousChannelIndex == requestedChannelIndex) {
                mCurrentChannel = requestedChannelIndex;
                mChannelIndex = requestedChannelIndex;
            } else {
                mCurrentChannel = previousChannelIndex;
                mChannelIndex = previousChannelIndex;
            }
            displayProgramInfo(3000);
            return true;
        }

        private int PooqFetchVideoUrl(ChannelData chData) {

            String authKey = AllTvBaseRowsSupportFragment.resolveChannelAuthKey(chData);

            if (authKey == null || authKey.length() < 10) {
                Log.e(TAG, "WAVVE auth key missing for channel " + chData.getId());
                return Utils.Code.NoAuthKey_err.ordinal();
            }

            try {

                String requestedQuality = getQualityTag(chData);
                JsonObject streamObject = requestWavveStream(chData, authKey, getStringById(R.string.POOQ_CHANNEL_URL), requestedQuality);

                if (!hasPlayableWavveUrl(streamObject) && !"auto".equals(requestedQuality)) {
                    logWavveStreamStatus(chData, requestedQuality, streamObject);
                    streamObject = requestWavveStream(chData, authKey, getStringById(R.string.POOQ_CHANNEL_URL), "auto");
                }

                if (streamObject == null) {
                    Log.e(TAG, "WAVVE stream response is null for channel " + chData.getId());
                    return Utils.Code.NoVideoUrl_err.ordinal();
                }

                videoUrl = getJsonString(streamObject, "playurl");
                if (videoUrl.length() == 0) {
                    videoUrl = getJsonString(streamObject, "liveurl");
                }
                videoCookie = getJsonString(streamObject, "awscookie");

                if (videoUrl == null || videoUrl.equals(getStringById(R.string.NULL_STR)) || videoUrl.length() == 0) {
                    logWavveStreamStatus(chData, "auto".equals(requestedQuality) ? requestedQuality : "auto", streamObject);
                    return Utils.Code.NoVideoUrl_err.ordinal();
                }

                return Utils.Code.FetchVideoUrlTask_OK.ordinal();
            } catch (Exception ex) {
                Log.e(TAG, "WAVVE stream fetch failed for channel " + chData.getId(), ex);
                return Utils.Code.NoVideoUrl_err.ordinal();
            }
        }

        private int TvingFetchVideoUrl(ChannelData chData) {

            String authKey = AllTvBaseRowsSupportFragment.resolveChannelAuthKey(chData);

            if (authKey == null || authKey.length() < 10) {
                Log.e(TAG, "TVING auth key missing for channel " + chData.getId());
                return Utils.Code.NoAuthKey_err.ordinal();
            }

            try {

                String channelId = chData.getId();
                String requestedQuality = requestedQualityOverride.length() > 0
                        ? requestedQualityOverride
                        : getQualityTag(chData);
                requestedQualityTag = getQualityTag(chData);
                String lastResultCode = "";
                String lastResultMessage = "";

                for (String qualityTag : getTvingQualityFallbackTags(requestedQuality)) {
                    TvingStreamInfo streamInfo = requestTvingStreamInfo(channelId, qualityTag, authKey);

                    if (streamInfo == null) {
                        continue;
                    }

                    lastResultCode = streamInfo.resultCode;
                    lastResultMessage = streamInfo.resultMessage;

                    if ("010".equals(streamInfo.resultCode)) {
                        return Utils.Code.NoAuthKey_err.ordinal();
                    }

                    TvingPlaybackUtils.PlaybackInfo playbackInfo = TvingPlaybackUtils.decryptPlaybackInfo(
                            channelId,
                            getJsonString(streamInfo.streamBroadcastObject, "broad_url"),
                            streamInfo.serverTime);

                    if (playbackInfo != null) {
                        videoUrl = playbackInfo.getVideoUrl();
                        videoCookie = playbackInfo.getVideoCookie();
                        resolvedQualityTag = qualityTag;

                        String switchSourceTag = qualityFallbackSourceTag.length() > 0
                                ? qualityFallbackSourceTag
                                : requestedQuality;
                        if (!switchSourceTag.equals(qualityTag)) {
                            videoInfoMessage = buildTvingQualitySwitchMessage(switchSourceTag, qualityTag);
                            Log.w(TAG, "TVING playback quality downgraded. channel=" + channelId
                                    + ", requested=" + switchSourceTag + ", actual=" + qualityTag);
                        }

                        Log.d(TAG, "TVING signed playback resolved. channel=" + channelId
                                + ", quality=" + qualityTag + ", cookie=" + (videoCookie.length() > 0));
                        return Utils.Code.FetchVideoUrlTask_OK.ordinal();
                    }

                    if (!"000".equals(streamInfo.resultCode)) {
                        Log.w(TAG, "TVING channel unavailable. channel=" + channelId
                                + ", quality=" + qualityTag
                                + ", resultCode=" + streamInfo.resultCode
                                + ", message=" + streamInfo.resultMessage);
                        continue;
                    }

                    String broadUrl = selectTvingBroadcastUrl(streamInfo.broadcastObject, qualityTag);
                    if (broadUrl.length() == 0) {
                        Log.w(TAG, "TVING fallback broadcast missing. channel=" + channelId
                                + ", quality=" + qualityTag);
                        continue;
                    }

                    videoUrl = broadUrl;
                    videoCookie = "";
                    resolvedQualityTag = qualityTag;

                    String switchSourceTag = qualityFallbackSourceTag.length() > 0
                            ? qualityFallbackSourceTag
                            : requestedQuality;
                    if (!switchSourceTag.equals(qualityTag)) {
                        videoInfoMessage = buildTvingQualitySwitchMessage(switchSourceTag, qualityTag);
                        Log.w(TAG, "TVING fallback quality downgraded. channel=" + channelId
                                + ", requested=" + switchSourceTag + ", actual=" + qualityTag);
                    }

                    Log.w(TAG, "TVING signed playback fallback used. channel=" + channelId
                            + ", quality=" + qualityTag);
                    return Utils.Code.FetchVideoUrlTask_OK.ordinal();
                }

                videoErrorMessage = buildTvingVideoErrorMessage(lastResultCode, lastResultMessage);
                Log.e(TAG, "TVING stream URL missing. channel=" + channelId
                        + ", resultCode=" + lastResultCode
                        + ", requestedQuality=" + requestedQuality);
                return Utils.Code.NoVideoUrl_err.ordinal();
            } catch (Exception ex) {
                Log.e(TAG, "TVING stream fetch failed for channel " + chData.getId(), ex);
                return Utils.Code.NoVideoUrl_err.ordinal();
            }
        }

        private TvingStreamInfo requestTvingStreamInfo(String channelId, String qualityTag, String authKey) {

            Long ts = System.currentTimeMillis() / 1000;
            String timestamp = ts.toString();

            HttpRequest request = HttpRequest.get("http://api.tving.com/v1/media/stream/info", true,
                    "apiKey", "1e7952d0917d6aab1f0293a063697610",
                    "info", "Y",
                    "networkCode", "CSND0900",
                    "osCode", "CSOD0900",
                    "teleCode", "CSCD0900",
                    "mediaCode", channelId,
                    "screenCode", "CSSD0100",
                    "streamCode", qualityTag,
                    "noCache", timestamp,
                    "callingFrom", "FLASH",
                    "adReq", "none",
                    "ooc", "")
                    .userAgent(getStringById(R.string.USERAGENT));

            TvingAuthUtils.applyApiHeaders(request, authKey);

            if (request == null || request.badRequest() || request.isBodyEmpty()) {
                Log.e(TAG, "TVING request failed. channel=" + channelId + ", quality=" + qualityTag);
                return null;
            }

            JsonObject body = new JsonParser().parse(request.body()).getAsJsonObject().getAsJsonObject("body");
            JsonObject resultObject = body.getAsJsonObject("result");
            String resultCode = getJsonString(resultObject, "code");
            String resultMessage = getJsonString(resultObject, "message");

            String serverTime = "";
            if (body.has("server") && body.get("server").isJsonObject()) {
                serverTime = getJsonString(body.getAsJsonObject("server"), "time");
            }

            JsonObject streamBroadcastObject = null;
            if (body.has("stream") && body.get("stream").isJsonObject()) {
                JsonObject streamObject = body.getAsJsonObject("stream");
                if (streamObject.has("broadcast") && streamObject.get("broadcast").isJsonObject()) {
                    streamBroadcastObject = streamObject.getAsJsonObject("broadcast");
                }
            }

            JsonObject broadcastObject = null;
            if (body.has("content") && body.get("content").isJsonObject()) {
                JsonObject contentObject = body.getAsJsonObject("content");
                JsonObject infoObject = contentObject != null ? contentObject.getAsJsonObject("info") : null;
                JsonObject scheduleObject = infoObject != null ? infoObject.getAsJsonObject("schedule") : null;
                JsonArray broadcastArray = scheduleObject != null ? scheduleObject.getAsJsonArray("broadcast_url") : null;
                if (broadcastArray != null && broadcastArray.size() > 0 && broadcastArray.get(0).isJsonObject()) {
                    broadcastObject = broadcastArray.get(0).getAsJsonObject();
                }
            }

            return new TvingStreamInfo(resultCode, resultMessage, serverTime, streamBroadcastObject, broadcastObject);
        }

        private int OksusuFetchVideoUrl(ChannelData chData) {

            String authKey = AllTvBaseRowsSupportFragment.resolveChannelAuthKey(chData);

            if (authKey == null || authKey.length() < 10)
                return Utils.Code.NoAuthKey_err.ordinal();

            try {

                String url = getStringById(R.string.OKSUSUVIDEO_URL) + String.valueOf(chData.getId());

                HttpRequest request = HttpRequest.get(url)
                        .userAgent("Mozilla/4.0")
                        .header(getStringById(R.string.COOKIE_STR), authKey);

                if(request == null || request.badRequest() || request.isBodyEmpty()) {
                    return Utils.Code.NoVideoUrl_err.ordinal();
                }

                String resultBody = request.body();

                if (resultBody.contains(getStringById(R.string.CONTENTINFO_STR))) {

                    String jsonStr = resultBody.substring(resultBody.indexOf(getStringById(R.string.CONTENTINFO_STR)) + 14,
                            resultBody.indexOf(getStringById(R.string.OKSUSUJSONSUB_STR)));

                    JsonParser jsonParser = new JsonParser();
                    JsonElement jsonElement = jsonParser.parse(jsonStr);

                    videoUrl = Utils.removeQuote(jsonElement.getAsJsonObject().get(getStringById(R.string.STREAMURL_STR))
                            .getAsJsonObject().get(getQualityTag(chData)).toString());

                    if (videoUrl.equals("null") || videoUrl.length() == 0) {
                        return Utils.Code.NoVideoUrl_err.ordinal();
                    }

                } else {
                    return Utils.Code.NoVideoUrl_err.ordinal();
                }

                return Utils.Code.FetchVideoUrlTask_OK.ordinal();
            } catch (Exception ex) {
                return Utils.Code.NoVideoUrl_err.ordinal();
            }

        }

        private boolean hasPlayableWavveUrl(JsonObject streamObject) {

            if (streamObject == null) {
                return false;
            }

            return "y".equals(getJsonString(streamObject, "play")) &&
                    (getJsonString(streamObject, "playurl").length() > 0 ||
                            getJsonString(streamObject, "liveurl").length() > 0);
        }

        private JsonObject requestWavveStream(ChannelData chData, String authKey, String requestUrl, String qualityTag) {

            HttpRequest request = HttpRequest.get(requestUrl, true,
                    "apikey", getStringById(R.string.POOQ_API_ACCESSKEY_STR),
                    "device", getStringById(R.string.PC_STR),
                    "partner", "pooq",
                    "service", "wavve",
                    "pooqzone", "none",
                    "region", "kor",
                    "drm", "none",
                    "targetage", "all",
                    "contentid", chData.getId(),
                    "audioChannel", "2ch",
                    "hdr", "sdr",
                    "videocodec", "avc",
                    "audiocodec", "aac",
                    "issurround", "n",
                    "format", "normal",
                    "withinsubtitle", "n",
                    "contenttype", "live",
                    "action", "hls",
                    "protocol", "hls",
                    "quality", qualityTag,
                    "deviceModelId", getStringById(R.string.PC_STR),
                    "guid", UUID.randomUUID().toString(),
                    "lastplayid", "none",
                    "authtype", "cookie",
                    "isabr", "y",
                    "ishevc", "n",
                    "productid", "www.wavve.com")
                    .userAgent(getStringById(R.string.USERAGENT))
                    .acceptJson();

            if (request == null) {
                return null;
            }

            request.header("wavve-credential", authKey);

            if (request.badRequest() || request.isBodyEmpty()) {
                Log.e(TAG, "WAVVE request failed. channel=" + chData.getId() + ", quality=" + qualityTag);
                return null;
            }

            String responseBody = request.body();
            JsonObject responseObject = new JsonParser().parse(responseBody).getAsJsonObject();
            logWavveStreamStatus(chData, qualityTag, responseObject);
            return responseObject;
        }

        private void logWavveStreamStatus(ChannelData chData, String qualityTag, JsonObject streamObject) {

            if (streamObject == null) {
                Log.e(TAG, "WAVVE empty stream response. channel=" + chData.getId() + ", quality=" + qualityTag);
                return;
            }

            Log.d(TAG, "WAVVE stream response. channel=" + chData.getId()
                    + ", quality=" + qualityTag
                    + ", play=" + getJsonString(streamObject, "play")
                    + ", playurl=" + getJsonString(streamObject, "playurl")
                    + ", liveurl=" + getJsonString(streamObject, "liveurl")
                    + ", warning=" + getJsonString(streamObject, "warning_kr"));
        }

        private String selectTvingBroadcastUrl(JsonObject broadcastObject, String qualityTag) {

            if (broadcastObject == null) {
                return "";
            }

            String[] candidates;
            if (qualityTag.equals(getStringById(R.string.TVING_MD_QUALITY_TAG))) {
                candidates = new String[]{"broad_url2", "broad_url1", "broad_url4", "broad_url5", "ndvr_host", "abr_url"};
            } else if (qualityTag.equals(getStringById(R.string.TVING_SD_QUALITY_TAG))) {
                candidates = new String[]{"broad_url1", "broad_url2", "broad_url4", "broad_url5", "ndvr_host", "abr_url"};
            } else if (qualityTag.equals(getStringById(R.string.TVING_HD_QUALITY_TAG))) {
                candidates = new String[]{"broad_url4", "broad_url1", "broad_url2", "broad_url5", "ndvr_host", "abr_url"};
            } else {
                candidates = new String[]{"broad_url5", "ndvr_host", "broad_url4", "broad_url1", "broad_url2", "abr_url"};
            }

            for (String candidate : candidates) {
                String candidateUrl = getJsonString(broadcastObject, candidate);
                if (candidateUrl.length() > 0) {
                    return candidateUrl;
                }
            }

            return "";
        }

        private ArrayList<String> getTvingQualityFallbackTags(String requestedQuality) {

            ArrayList<String> candidates = new ArrayList<>();

            addTvingQualityCandidate(candidates, requestedQuality);
            addTvingQualityCandidate(candidates, getStringById(R.string.TVING_HD_QUALITY_TAG));
            addTvingQualityCandidate(candidates, getStringById(R.string.TVING_SD_QUALITY_TAG));
            addTvingQualityCandidate(candidates, getStringById(R.string.TVING_MD_QUALITY_TAG));

            return candidates;
        }

        private void addTvingQualityCandidate(ArrayList<String> candidates, String qualityTag) {

            if (qualityTag == null || qualityTag.length() == 0 || candidates.contains(qualityTag)) {
                return;
            }

            candidates.add(qualityTag);
        }

        private String buildTvingVideoErrorMessage(String resultCode, String resultMessage) {

            if (resultMessage != null && resultMessage.trim().length() > 0) {
                return resultMessage.trim();
            }

            if ("080".equals(resultCode) || "090".equals(resultCode)) {
                return getStringById(R.string.geturl_error);
            }

            return "";
        }

        private String buildTvingQualitySwitchMessage(String requestedQuality, String actualQuality) {

            String requestedLabel = getTvingQualityLabel(requestedQuality);
            String actualLabel = getTvingQualityLabel(actualQuality);

            if (requestedLabel.length() == 0 || actualLabel.length() == 0 || requestedLabel.equals(actualLabel)) {
                return "";
            }

            return getString(R.string.quality_fallback_message, requestedLabel, actualLabel);
        }

        private String getTvingQualityLabel(String qualityTag) {

            if (getStringById(R.string.TVING_FHD_QUALITY_TAG).equals(qualityTag)) {
                return getStringById(R.string.fullhd);
            }

            if (getStringById(R.string.TVING_HD_QUALITY_TAG).equals(qualityTag)) {
                return getStringById(R.string.hd);
            }

            if (getStringById(R.string.TVING_SD_QUALITY_TAG).equals(qualityTag)) {
                return getStringById(R.string.sd);
            }

            if (getStringById(R.string.TVING_MD_QUALITY_TAG).equals(qualityTag)) {
                return getStringById(R.string.mobile);
            }

            return "";
        }

        private class TvingStreamInfo {
            private final String resultCode;
            private final String resultMessage;
            private final String serverTime;
            private final JsonObject streamBroadcastObject;
            private final JsonObject broadcastObject;

            TvingStreamInfo(String resultCode, String resultMessage, String serverTime,
                            JsonObject streamBroadcastObject, JsonObject broadcastObject) {
                this.resultCode = resultCode;
                this.resultMessage = resultMessage;
                this.serverTime = serverTime;
                this.streamBroadcastObject = streamBroadcastObject;
                this.broadcastObject = broadcastObject;
            }
        }

        private String getJsonString(JsonObject object, String key) {

            if (object == null || key == null || !object.has(key) || object.get(key).isJsonNull()) {
                return "";
            }

            return Utils.removeQuote(object.get(key).getAsString());
        }

        private String getQualityTag(ChannelData chData) {

            int siteType = chData.getSiteType();
            int qualityType = chData.getQualityType();

            if(siteType == Utils.SiteType.Pooq.ordinal()) {

                switch (SettingsData.PooqQualityType.values()[qualityType]) {
                    case Mobile:
                        return getStringById(R.string.POOQ_MOBILE_QUALITY_TAG);
                    case SD:
                        return getStringById(R.string.POOQ_SD_QUALITY_TAG);
                    case HD:
                        return getStringById(R.string.POOQ_HD_QUALITY_TAG);
                    case FHD:
                        return getStringById(R.string.POOQ_FHD_QUALITY_TAG);
                }

                return getStringById(R.string.POOQ_SD_QUALITY_TAG);

            } else if(siteType == Utils.SiteType.Tving.ordinal()) {

                switch (SettingsData.TvingQualityType.values()[qualityType]) {
                    case AUTO:
                        return getStringById(R.string.TVING_FHD_QUALITY_TAG);
                    case MD:
                        return getStringById(R.string.TVING_MD_QUALITY_TAG);
                    case SD:
                        return getStringById(R.string.TVING_SD_QUALITY_TAG);
                    case HD:
                        return getStringById(R.string.TVING_HD_QUALITY_TAG);
                    case FHD:
                        return getStringById(R.string.TVING_FHD_QUALITY_TAG);
                }

                return getStringById(R.string.TVING_HD_QUALITY_TAG);

            } else if(siteType == Utils.SiteType.Oksusu.ordinal()) {

                switch (SettingsData.OksusuQualityType.values()[qualityType]) {
                    case AUTO:
                        return getStringById(R.string.URLAUTO_STR);
                    case FullHD:
                        return getStringById(R.string.URLFHD_STR);
                    case HD:
                        return getStringById(R.string.URLHD_STR);
                    case SD:
                        return getStringById(R.string.URLSD_STR);
                }

                return getStringById(R.string.URLAUTO_STR);

            }

            return "";
        }

    }

    private boolean tryRecoverTvingPlayback(ExoPlaybackException error) {

        if (mTvingQualityRetryInProgress || mCurrentChannel < 0 || mCurrentChannel >= mChannels.size()) {
            return false;
        }

        ChannelData currentChannel = mChannels.get(mCurrentChannel);
        if (currentChannel.getSiteType() != Utils.SiteType.Tving.ordinal()) {
            return false;
        }

        String currentQualityTag = mTvingResolvedQualityTag.length() > 0
                ? mTvingResolvedQualityTag
                : mTvingRequestedQualityTag;

        if (currentQualityTag.length() == 0) {
            currentQualityTag = getTvingConfiguredQualityTag(currentChannel);
        }
        String nextQualityTag = getLowerTvingQualityTag(currentQualityTag);

        if (nextQualityTag.length() == 0) {
            return false;
        }

        mTvingQualityRetryInProgress = true;
        mProgressBar.setVisibility(View.VISIBLE);

        if (mPlayer != null) {
            mPlayer.stop(true);
        }

        Log.w(TAG, "TVING playback retry requested. channel=" + currentChannel.getId()
                + ", failedQuality=" + currentQualityTag + ", retryQuality=" + nextQualityTag
                + ", errorType=" + error.type);

        new FetchVideoUrlTask(nextQualityTag, currentQualityTag).execute(mCurrentChannel);
        return true;
    }

    private String getLowerTvingQualityTag(String currentQualityTag) {

        if (getStringById(R.string.TVING_FHD_QUALITY_TAG).equals(currentQualityTag)) {
            return getStringById(R.string.TVING_HD_QUALITY_TAG);
        }

        if (getStringById(R.string.TVING_HD_QUALITY_TAG).equals(currentQualityTag)) {
            return getStringById(R.string.TVING_SD_QUALITY_TAG);
        }

        if (getStringById(R.string.TVING_SD_QUALITY_TAG).equals(currentQualityTag)) {
            return getStringById(R.string.TVING_MD_QUALITY_TAG);
        }

        return "";
    }

    private String getTvingConfiguredQualityTag(ChannelData chData) {

        int qualityType = chData.getQualityType();

        switch (SettingsData.TvingQualityType.values()[qualityType]) {
            case AUTO:
                return getStringById(R.string.TVING_FHD_QUALITY_TAG);
            case MD:
                return getStringById(R.string.TVING_MD_QUALITY_TAG);
            case SD:
                return getStringById(R.string.TVING_SD_QUALITY_TAG);
            case HD:
                return getStringById(R.string.TVING_HD_QUALITY_TAG);
            case FHD:
                return getStringById(R.string.TVING_FHD_QUALITY_TAG);
        }

        return getStringById(R.string.TVING_HD_QUALITY_TAG);
    }

}
